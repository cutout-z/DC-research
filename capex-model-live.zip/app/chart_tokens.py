"""Chart styling for the ai-dc frontend.

One source for every figure's look, so a chart cannot drift. Values mirror the CSS tokens in
`app/static/css/tailwind.src.css` — Plotly renders to SVG, where CSS variables cannot reach, so
every figure is built once per theme and the page swaps them when the theme flips.

The categorical palette is the dataviz reference order, validated against these surfaces
(`#171717` dark, `#ffffff` light): adjacent-pair CVD ΔE ≥ 8.4, normal-vision ΔE ≥ 19.3. Three light
slots (aqua, yellow, magenta) sit under 3:1 on white, so every multi-series chart carries a legend
and a hover layer — never colour alone.
"""
from __future__ import annotations

import json

FONT = '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Inter, system-ui, sans-serif'
THEMES = ("dark", "light")

# Categorical slots, fixed order. Stepped per theme, not flipped.
CATEGORICAL = {
    "dark":  ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"],
    "light": ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"],
}
OTHER = {"dark": "#6b6b6b", "light": "#a3a3a3"}  # "Other" is a grey, never a ninth hue

# Colour follows the entity, never its rank: NSW1 is the same blue on every page.
REGION_SLOT = {"NSW1": 0, "QLD1": 1, "VIC1": 2, "SA1": 3, "TAS1": 4, "WA": 5, "NT": 6}
# Canonical stack order; adjacent slots are the validated adjacent pairs.
FUEL_ORDER = ["Clean Baseload", "Fossil", "VRE", "Storage", "Other"]
FUEL_SLOT = {"Clean Baseload": 0, "Fossil": 1, "VRE": 2, "Storage": 3}

# Development stage is ORDINAL (maturity), so it is one hue, strong -> faint, not traffic lights:
# red/green would read as bad/good. Validated with --ordinal on both surfaces.
STAGE_RAMP = {
    "dark":  ["#b7d3f6", "#86b6ef", "#5598e7", "#2a78d6", "#1c5cab"],
    "light": ["#0d366b", "#1c5cab", "#2a78d6", "#5598e7", "#86b6ef"],
}
STAGE_INDEX = {  # delivery-confidence tiers (forecast) and plain statuses (region, status donut)
    "Operating": 0, "Under Construction": 1, "Approved — Power Secured": 2, "Approved": 2,
    "Approved — Grid Pending": 3, "Proposed": 4,
    "Announced": 3,  # Company Analysis folds Proposed + Approved into one bucket
}
STAGE_ORDER = ["Operating", "Under Construction", "Approved", "Proposed"]

# Fixed categorical identities for AU project dimensions (colour follows the category everywhere).
CATEGORY_SLOT = {
    "operator_type": {"Colocation": 0, "Developer": 1, "Technology": 2, "Telecom": 3, "Hyperscaler": 4},
    "size_class": {"Hyperscale (>200MW)": 0, "Large (50-200MW)": 1, "Mid-size (10-50MW)": 2, "Small (<10MW)": 3},
    "workload_type": {"AI/HPC": 0, "Traditional": 1, "Cloud": 2, "Cloud/AI": 3},
    "power_strategy": {"Grid": 0, "Renewables": 2, "Behind-the-meter hybrid solar/BESS": 3,
                       "Grid / onsite generation proposed": 1, "Onsite gas generation": 4},
}


def stage_color(stage: str, theme: str = "dark") -> str:
    i = STAGE_INDEX.get(stage)
    return OTHER[theme] if i is None else STAGE_RAMP[theme][i]


def category_color(dimension: str, value: str, theme: str = "dark") -> str:
    if dimension == "status":
        return stage_color(value, theme)
    slot = CATEGORY_SLOT.get(dimension, {}).get(value)
    return OTHER[theme] if slot is None else series(theme, slot)


_PALETTE = {
    "dark": {
        "surface": "#171717", "text": "#fafafa", "muted": "#a3a3a3", "faint": "#898989",
        "grid": "#262626", "axis": "#3a3a3a", "hover_bg": "#1e1e1e", "hover_line": "#3a3a3a",
    },
    "light": {
        "surface": "#ffffff", "text": "#0a0a0a", "muted": "#525252", "faint": "#737373",
        "grid": "#efefef", "axis": "#d4d4d4", "hover_bg": "#ffffff", "hover_line": "#e7e7e7",
    },
}


def palette(theme: str = "dark") -> dict:
    return _PALETTE.get(theme, _PALETTE["dark"])


def series(theme: str, slot: int) -> str:
    return CATEGORICAL[theme][slot % 8]


# LLM providers (llm_perf.PROVIDER_COLOURS' eight). Legend and trace order follow the slot order,
# so line charts only ever put validated adjacent pairs side by side. Scatter forms, where any two
# marks can touch, carry at most three coloured providers (the all-pairs cap); see figures_llm.
PROVIDER_SLOT = {"Google": 0, "Anthropic": 1, "OpenAI": 2, "xAI": 3, "DeepSeek": 4, "Mistral": 5,
                 "Meta": 6, "Alibaba": 7}
PROVIDER_ORDER = sorted(PROVIDER_SLOT, key=PROVIDER_SLOT.get)


# Licence is a two-way identity used across the LLM pages: one meaning per colour, page-wide.
LICENCE_SLOT = {"Proprietary": 0, "Open Source": 1}


def licence_color(licence: str, theme: str = "dark") -> str:
    slot = LICENCE_SLOT.get(licence)
    return OTHER[theme] if slot is None else series(theme, slot)


# Countries of LLM labs. "Other" and "Unknown" are greys, never a hue (Unknown also carries a hatch).
COUNTRY_SLOT = {"US": 0, "CN": 1, "FR": 2, "CA": 3}


def country_color(code: str, theme: str = "dark") -> str:
    slot = COUNTRY_SLOT.get(code)
    return OTHER[theme] if slot is None else series(theme, slot)


def provider_color(provider: str, theme: str = "dark") -> str:
    slot = PROVIDER_SLOT.get(provider)
    return OTHER[theme] if slot is None else series(theme, slot)


def region_color(region: str, theme: str = "dark") -> str:
    slot = REGION_SLOT.get(region)
    return OTHER[theme] if slot is None else series(theme, slot)


def fuel_color(category: str, theme: str = "dark") -> str:
    slot = FUEL_SLOT.get(category)
    return OTHER[theme] if slot is None else series(theme, slot)


def wash(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha})"


def style_parts(theme: str = "dark", *, hovermode: str | None = "x unified",
                showlegend: bool = False, height: int = 280) -> tuple[dict, dict, dict]:
    """The shared look as plain dicts: (layout, x axis, y axis). style() applies them to a plotly Figure; a figure
    built as a dict without plotly (figures_capex_model, which also runs in the browser) merges them itself."""
    p = palette(theme)
    layout = dict(
        template=None,
        font=dict(family=FONT, size=12, color=p["muted"]),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        colorway=CATEGORICAL[theme],
        margin=dict(l=0, r=0, t=4, b=0),
        height=height,
        hovermode=hovermode,
        hoverlabel=dict(bgcolor=p["hover_bg"], bordercolor=p["hover_line"],
                        font=dict(family=FONT, size=12, color=p["text"]), namelength=-1),
        showlegend=showlegend,
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="left", x=0,
                    font=dict(size=12, color=p["muted"]), bgcolor="rgba(0,0,0,0)",
                    itemwidth=30, itemsizing="constant", traceorder="normal"),
        barcornerradius=4,
        bargap=0.45,
    )
    # ticklabelstandoff: the x labels sit 6px clear of the axis, so the y axis's bottom label ("$0B",
    # "0%"), centred on that line, no longer runs into the first x label on small charts ("$0BJul 2024").
    xaxis = dict(showgrid=False, zeroline=False, showline=True, linecolor=p["axis"], linewidth=1,
                 ticks="", tickfont=dict(size=12, color=p["faint"]), automargin=True, ticklabelstandoff=6,
                 showspikes=True, spikemode="across", spikethickness=1, spikedash="solid",
                 spikecolor=p["axis"], spikesnap="cursor")
    yaxis = dict(showgrid=True, gridcolor=p["grid"], gridwidth=1, zeroline=False, showline=False,
                 ticks="", tickfont=dict(size=12, color=p["faint"]), automargin=True,
                 separatethousands=True)
    return layout, xaxis, yaxis


def style(fig, theme: str = "dark", *, hovermode: str | None = "x unified",
          showlegend: bool = False, height: int = 280):
    """Apply the shared look. Charts carry no title — the card header owns it."""
    layout, xaxis, yaxis = style_parts(theme, hovermode=hovermode, showlegend=showlegend, height=height)
    fig.update_layout(**layout)
    fig.update_xaxes(**xaxis)
    fig.update_yaxes(**yaxis)
    return fig


def both(build) -> str:
    """Build a figure once per theme and return {"dark": fig, "light": fig} as JSON.

    `build(theme)` must return a plotly Figure, or a figure already as a plain dict (figures_capex_model). The page
    redraws from the other key when the theme flips — this is how charts follow the toggle without a server round-trip.
    """
    return json.dumps({t: (f if isinstance(f := build(t), dict) else json.loads(f.to_json())) for t in THEMES})


PLOTLY_CONFIG = {
    "displayModeBar": False,
    "responsive": True,
    "displaylogo": False,
}


# Hyperscalers on the capex pages. Alphabet shares Google's slot and Meta Meta's (the LLM pages), so
# a company keeps one colour across the app; the rest take the free slots. Traces follow slot order.
HYPERSCALER_SLOT = {"Alphabet": 0, "Amazon": 1, "Microsoft": 2, "Apple": 3, "CoreWeave": 4, "Oracle": 5, "Meta": 6}


def hyperscaler_color(company: str, theme: str = "dark") -> str:
    slot = HYPERSCALER_SLOT.get(company)
    return OTHER[theme] if slot is None else series(theme, slot)


# Semi bellwethers (Other Signals). Slots chosen near each brand: ASML blue, TSMC red-orange, NVIDIA green.
SEMI_SLOT = {"ASML": 0, "TSMC": 1, "NVIDIA": 2}


def semi_color(company: str, theme: str = "dark") -> str:
    slot = SEMI_SLOT.get(company)
    return OTHER[theme] if slot is None else series(theme, slot)
