"""Figures for the AI capex return model: coverage by fiscal year, and what has to be covered each forecast year.

Built from view-model numbers only (app/views/capex_model.py); look from chart_tokens, so both themes and the
hover layer follow the rest of the app. Units are US$ bn; coverage is a multiple (x).

Plain dicts, not plotly Figures: this module also runs in the reader's browser (Pyodide, app/capex_model/live.py),
where plotly's Python package is not available. Each dict is the figure plotly's own to_json gave before
(tests/test_capex_model_live.py builds a plotly Figure from it and checks plotly keeps every key as given).
"""
from __future__ import annotations

from app import chart_tokens as ct

# Scenario lines. Central is the reading the page leads with: ink, thickest. Favourable and adverse take two
# categorical slots (the same two on every chart of the page).
SCN_SLOT = {"favourable": 2, "adverse": 1}
SCN_NAME = {"favourable": "Favourable", "central": "Central", "adverse": "Adverse"}


def scn_color(scn: str, theme: str) -> str:
    return ct.palette(theme)["text"] if scn == "central" else ct.series(theme, SCN_SLOT[scn])


# Forecast bands. Capital requirement is the neutral grey; rent already in place a wash of ink; the committed
# rent from leases not yet commenced its own hue (L3: a separately coloured band with its own legend entry).
def band_colors(theme: str) -> dict:
    p = ct.palette(theme)
    # No coloured gap between stacked segments: a surface-coloured outline lifts the stack off the baseline (design
    # language: stacked composition sits on the baseline; the fix is a zero-width gap).
    return {"capital": ct.wash(p["text"], 0.50), "rent": ct.wash(p["text"], 0.22), "committed": ct.series(theme, 3), "mark": p["text"]}


def _figure(theme: str, data: list, height: int, xaxis: dict, yaxis: dict, **layout) -> dict:
    """A figure dict in the shared look (ct.style_parts), with this chart's own layout and axis settings on top."""
    base, bx, by = ct.style_parts(theme, hovermode="closest", height=height)
    base["template"] = {}   # what plotly writes for template=None
    return {"data": data, "layout": {**base, **layout, "xaxis": {**bx, **xaxis}, "yaxis": {**by, **yaxis}}}


def fig_coverage(theme: str, series: dict, y_cap: float | None, shade: dict | None, active: str) -> dict:
    """Coverage by fiscal year for the three scenario sets, a 1.00x line, and (when the opening-stock
    assumption dominates the early years) a shaded span. A point above the cap is drawn at the edge and labelled
    with its value, so the early years cannot flatten the later ones."""
    p = ct.palette(theme)
    years = sorted({pt["year"] for pts in series.values() for pt in pts})
    data, notes = [], []
    for scn in ("adverse", "favourable", "central"):
        pts = series[scn]
        ys = [pt["cov"] for pt in pts]
        shown = [None if v is None else (min(v, y_cap) if y_cap else v) for v in ys]
        w = 3 if scn == "central" else 1.75
        data.append({
            "customdata": [[("n/a" if v is None else f"{v:.2f}x"), pt["n"]] for v, pt in zip(ys, pts)],
            "hovertemplate": f"<b>{SCN_NAME[scn]}</b> FY%{{x}}: %{{customdata[0]}} · %{{customdata[1]}} entities<extra></extra>",
            "line": {"color": scn_color(scn, theme), "dash": "solid", "width": w}, "marker": {"size": 8 if scn == "central" else 5},
            "mode": "lines+markers", "name": SCN_NAME[scn], "x": [pt["year"] for pt in pts], "y": shown, "type": "scatter"})
        if y_cap:
            for v, pt in zip(ys, pts):
                if v is not None and v > y_cap and scn == active:
                    notes.append({"font": {"color": p["muted"], "size": 11}, "showarrow": False, "text": f"↑ {v:.1f}x",
                                  "x": pt["year"], "xshift": 18, "y": y_cap, "yshift": -2})
    shapes = [{"line": {"color": p["muted"], "dash": "dash", "width": 1}, "type": "line",
               "x0": 0, "x1": 1, "xref": "x domain", "y0": 1.0, "y1": 1.0, "yref": "y"}]
    notes.append({"font": {"color": p["muted"], "size": 11}, "showarrow": False, "text": "1.00x",
                  "x": 1, "xanchor": "right", "xref": "x domain", "y": 1.0, "yanchor": "bottom", "yref": "y"})
    if shade:
        shapes.append({"fillcolor": ct.wash(p["text"], 0.07), "layer": "below", "line": {"width": 0}, "type": "rect",
                       "x0": min(years) - 0.5, "x1": shade["x1"], "xref": "x", "y0": 0, "y1": 1, "yref": "y domain"})
        notes.append({"font": {"color": p["faint"], "size": 11}, "showarrow": False, "text": "opening-stock<br>assumption dominates",
                      "x": (min(years) - 0.5 + shade["x1"]) / 2, "y": 1, "yanchor": "top", "yref": "paper"})
    top = y_cap or max([v for pts in series.values() for v in [pt["cov"] for pt in pts] if v is not None] + [1.5])
    return _figure(theme, data, 340, {"type": "linear", "dtick": 1, "tickformat": "d", "tickprefix": "FY"},
                   {"ticksuffix": "x", "rangemode": "tozero", "range": [0, top * 1.08], "separatethousands": True},
                   shapes=shapes, annotations=notes)


def fig_forecast(theme: str, cats: list, capital: list, rent: list, committed: list, pre: list) -> dict:
    """Stacked bands per year (capital requirement, operating rent in place, committed rent from leases not yet
    commenced) against the cash the businesses earn before rent at the latest fiscal year's revenue."""
    c = band_colors(theme)
    data = [{"hovertemplate": f"<b>{name}</b> · %{{x}}: $%{{y:,.1f}}B<extra></extra>", "marker": {"color": col, "line": {"width": 0}},
             "name": name, "x": cats, "y": vals, "type": "bar"}
            for name, vals, col in (("Capital requirement", capital, c["capital"]), ("Operating rent already in place", rent, c["rent"]),
                                    ("Committed rent, leases not yet commenced", committed, c["committed"]))]
    data.append({"hovertemplate": "<b>Cash before rent at latest revenue</b> · %{x}: $%{y:,.1f}B<extra></extra>",
                 "marker": {"line": {"color": c["mark"], "width": 3}, "size": 34, "symbol": "line-ew"}, "mode": "markers",
                 "name": "Cash earned before rent at the latest year's revenue", "x": cats, "y": pre, "type": "scatter"})
    return _figure(theme, data, 380, {"type": "category", "showspikes": False},
                   {"tickprefix": "$", "ticksuffix": "B", "rangemode": "tozero"}, barmode="stack", bargap=0.5)
