"""Bundle stub: the app's app/views/__init__.py imports every page."""
