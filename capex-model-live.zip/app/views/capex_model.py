"""View models for the AI capex return model (/capex_return_model).

The numbers come from app/capex_model/compute.py (the model's composition around its reference engine) and the
files read by app/data_capex_model.py; this layer only arranges them for the templates and words them. No number
is computed here that the model does not return, except sums and ratios of model outputs (shown as such).
"""
from __future__ import annotations

import math
from dataclasses import replace

from app import chart_tokens as ct
from app import data_capex_model as dcm
from app import figures_capex_model as fcm
from app.capex_model import compute as C
from app.content import capex_return_model as crc
from app.datatable import Col, TableDef, register, view as table_view

__all__ = ["crm_filter", "crm_results", "capex_return_model"]

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
SCENARIOS = ("central", "favourable", "adverse")
LIVES = (4, 5, 6)
LEASES = ("rent", "capex")
BONUS = ("on", "off")
TERMS = ("mid", "max")
# The sliders: query name -> (lowest, highest, step). Hurdle and tax are in percent. The ranges are the model
# page's (analysis/build_dashboard_v2.py in the model repo); the hurdle also keeps the 20% this page offered before.
SLIDERS = {"hurdle": (8, 20, 0.5), "life_fac": (15, 25, 1), "lag_it": (0, 2, 0.25), "lag_fac": (0, 3, 0.25), "tax": (15, 21, 1)}
# Statuses that are not a plain reading of a filing get the caution pill; every status carries its word.
CAUTION = ("assumption", "gap")


# --------------------------------------------------------------------------- formatting (display only)

def _m(t: str) -> str:
    return t.replace("-", "−")


def bn(v, d=1):
    return "n/a" if v is None or not math.isfinite(v) else _m(f"{v / 1000:,.{d}f}")


def usd_bn(v, d=0):
    return "n/a" if v is None or not math.isfinite(v) else f"${v / 1000:,.{d}f}bn"


def usd_tn(v):
    return "n/a" if v is None or not math.isfinite(v) else f"${v / 1e6:,.2f}tn"


def fx(v):
    return "n/a" if v is None or not math.isfinite(v) else _m(f"{v:.2f}x")


def pct(v, d=1):
    return "n/a" if v is None or not math.isfinite(v) else _m(f"{v * 100:.{d}f}%")


def spct(v, d=0):
    return "n/a" if v is None or not math.isfinite(v) else f"{'+' if v >= 0 else '−'}{abs(v) * 100:.{d}f}%"


def num(v, d=0):
    return "n/a" if v is None or not math.isfinite(v) else _m(f"{v:,.{d}f}")


def month_year(t):
    y = math.floor(t + 1e-9)
    mo = round((t - y) * 12)
    if mo >= 12:
        y, mo = y + 1, mo - 12
    return f"{MONTHS[mo]} {y}"


def end_month_year(t):
    return month_year(t - 1 / 12 + 1e-9)


def ltm_end_text(p) -> str | None:
    return end_month_year(p["end"]) if p and p.get("end") is not None else None


def ltm_label(S: C.Scenario) -> str:
    """Each company's own LTM window, labelled with the actual months: "LTM to Jun 2026 (Oracle to Aug 2026)"."""
    by, order = {}, []
    for b in S.cloud:
        m = ltm_end_text(S.ltm_per.get(b.name))
        if not m:
            continue
        if m not in by:
            by[m] = []
            order.append(m)
        by[m].append(b.name)
    if not order:
        return "LTM"
    order.sort(key=lambda m: -len(by[m]))
    rest = [", ".join(by[m]) + " to " + m for m in order[1:]]
    return "LTM to " + order[0] + (f" ({'; '.join(rest)})" if rest else "")


def ltm_why_all(S: C.Scenario) -> str:
    return " | ".join(f"{b.name}: {S.ltm_per[b.name]['why']}" for b in S.cloud if S.ltm_per.get(b.name, {}).get("why"))


def hurdle_label(h: float) -> str:
    return f"{h * 100:g}%"


# --------------------------------------------------------------------------- the return model page

def _pick(qp, name, allowed, default, cast=str):
    try:
        v = cast(qp.get(name))
    except (TypeError, ValueError):
        return default
    return v if v in allowed else default


def _slider(qp, name, default: float) -> float:
    """A slider value from a query string: a number in the slider's range, on its step. Anything else is the default."""
    lo, hi, step = SLIDERS[name]
    try:
        v = float(qp.get(name))
    except (TypeError, ValueError):
        return default
    if not lo <= v <= hi:   # also nan and inf
        return default
    n = round((v - lo) / step)
    return lo + n * step if math.isclose(lo + n * step, v, abs_tol=1e-9) else default


def crm_filter(qp) -> dict:
    """The controls from a query string. Anything not one of the offered options, or off a slider's range or step,
    falls back to the default (the inputs' params_default)."""
    data = dcm.inputs()
    d = C.default_params(data) if data else C.Params()
    return {"scenario": _pick(qp, "scenario", SCENARIOS, d.scenario),
            "hurdle": _slider(qp, "hurdle", round(d.hurdle * 100, 6)),
            "life": _pick(qp, "life", LIVES, int(d.life_it), int),
            "life_fac": _slider(qp, "life_fac", d.life_fac),
            "lag_it": _slider(qp, "lag_it", d.lag_it),
            "lag_fac": _slider(qp, "lag_fac", d.lag_fac),
            "tax": _slider(qp, "tax", round(d.tax * 100, 6)),
            "bonus": _pick(qp, "bonus", BONUS, "on" if d.bonus else "off"),
            "leases": _pick(qp, "leases", LEASES, d.lease_mode),
            "term": _pick(qp, "term", TERMS, d.lease_pick)}


def params_of(f: dict, data: dict) -> C.Params:
    return replace(C.default_params(data), hurdle=round(f["hurdle"] / 100, 6), life_it=f["life"], life_fac=f["life_fac"],
                   lag_it=f["lag_it"], lag_fac=f["lag_fac"], tax=round(f["tax"] / 100, 6), bonus=f["bonus"] == "on",
                   scenario=f["scenario"], lease_mode=f["leases"], lease_pick=f["term"])


def _g(v: float) -> str:
    return f"{v:g}"


def _controls(f: dict) -> dict:
    """What the controls form shows: each slider with its range, step and current value, and the radio groups."""
    def slider(name, label, help_, unit):
        lo, hi, step = SLIDERS[name]
        return {"name": name, "label": label, "help": help_, "min": _g(lo), "max": _g(hi), "step": _g(step),
                "value": _g(f[name]), "unit": unit}
    return {"sliders": [slider("hurdle", crc.HURDLE_LABEL, crc.HURDLE_HELP, "%"),
                        slider("life_fac", crc.LIFE_FAC_LABEL, crc.LIFE_FAC_HELP, " years"),
                        slider("lag_it", crc.LAG_IT_LABEL, crc.LAG_HELP, " years"),
                        slider("lag_fac", crc.LAG_FAC_LABEL, crc.LAG_HELP, " years"),
                        slider("tax", crc.TAX_LABEL, crc.TAX_HELP, "%")],
            "scenarios": [(s, fcm.SCN_NAME[s]) for s in SCENARIOS], "lives": [(l, f"{l} years") for l in LIVES],
            "bonus": [(k, crc.BONUS_OPTIONS[k]) for k in BONUS], "leases": [(k, crc.LEASES_OPTIONS[k]) for k in LEASES],
            "terms": [(k, crc.TERM_OPTIONS[k]) for k in TERMS]}


def _chips(row: C.Row, S: C.Scenario):
    y, f = row.y, row.flow
    out = [("revenue", y["revenue"]["status"]), ("contribution", y["contribution"]["status"]), ("capex", y["capex"]["status"])]
    if f.rent > 0:
        out.append(("rent", y["rent"]["status"]))
    flags = []
    if row.rent_gap:
        flags.append("rent: not disclosed")
    if row.capex_partial:
        flags.append("capex partial: understated")
    if row.con_incomplete:
        flags.append("contribution: low end only")
    return [{"label": a, "status": b} for a, b in out], flags


def _share_text(b: C.Built) -> dict:
    ss = b.ent.get("scenario_share")
    if not ss or (ss.get("low") == ss.get("high") == ss.get("mid")):
        return {"single": True, "key": "", "value": "", "tail": ""}
    v = ss.get(b.key)
    tail = ("contribution share only; capex, rent and leases are whole company" if ss.get("basis") == "contribution_share" else "")
    return {"single": False, "key": b.key, "value": pct(v, 1) if v is not None else "", "tail": tail}


def _scenario_notes(R: C.Result, data: dict) -> list[dict]:
    out = []
    for e in data["entities"]:
        ss = e.get("scenario_share")
        if not ss or (ss.get("low") == ss.get("high") == ss.get("mid")):
            continue

        def t(key):
            return key + (f" ({pct(ss[key], 1)})" if ss.get(key) is not None else "")
        out.append({"name": e["name"], "fav": t(R.keys["favourable"][e["name"]]), "cen": t(R.keys["central"][e["name"]]),
                    "adv": t(R.keys["adverse"][e["name"]]),
                    "tail": ("share of contribution only (filed cloud revenue share to whole company); capex, rent and leases are "
                             "whole company" if ss.get("basis") == "contribution_share" else (ss.get("basis") or ""))})
    return out


def _be_text(S: C.Scenario) -> str:
    if S.breakeven is not None:
        return pct(S.breakeven, 1)
    return {"above": "above 100%", "below": "below 0%"}.get(S.breakeven_side, "n/a")


def _short(component: str) -> str:
    return component.split(":")[0].strip()


def system_lede(O: dict) -> str:
    """The system memo's lead, from the block's own totals and components (nothing named that the block does not carry)."""
    lower = [_short(c["component"]) for c in O["revenue"] if c.get("in_lower") and c.get("value") is not None]
    upper_only = [_short(c["component"]) for c in O["revenue"] if c.get("in_upper") and not c.get("in_lower") and c.get("value") is not None]
    nd = O.get("not_disclosed") or []
    parts = [f"The labs' own stated revenue from their end customers adds up to at least ${num(O['revenue_lower'] / 1000)}bn a year "
             f"({', '.join(lower)}; on their latest statements and filings)."]
    if upper_only:
        parts.append(f"Adding the AI run-rates stated by {', '.join(upper_only)} gives ${num(O['revenue_upper'] / 1000)}bn, but that can count the "
                     "same dollars twice, because those run-rates may include what labs pay for compute and lab models resold through the clouds.")
    parts.append(f"On the other side, capex for the companies in the capex table below, for each company's latest guided year, is about "
                 f"${num(O['capex_total'] / 1000)}bn. The two sides are not symmetric: that capex includes non-AI spending (no company discloses its "
                 "AI share)" + (f", and {', '.join(nd)} state no AI revenue to set against theirs." if nd else "."))
    parts.append(f"So a year of stated end-customer AI revenue is {pct(O['ratio_lower'], 0)} to {pct(O['ratio_upper'], 0)} of a year of capex.")
    return " ".join(parts)


def _system(data: dict) -> dict | None:
    O = data.get("system_overlay")
    if not O:
        return None

    def srcs(c):
        rs = [dcm.resolve_src(x) for x in (c.get("src") or [])]
        return {"text": " · ".join(dict.fromkeys(r["text"] for r in rs if r["kind"] != "method")),
                "link": next((r["link"] for r in rs if r["link"]), None)}
    rev = []
    for c in O["revenue"]:
        if c.get("value") is None:
            rev.append({"component": c["component"], "gap": True, "note": c.get("note") or ""})
            continue
        lv = c.get("lower_value", c["value"])
        rev.append({"component": c["component"], "gap": False, "stated": bn(c["value"]), "lower": bn(lv) if c.get("in_lower") else None,
                    "upper": bn(c["value"]) if c.get("in_upper") else None, "as_of": c.get("as_of") or "", "basis": c.get("basis") or "",
                    "status": c.get("status") or "", "stated_by": c.get("stated_by") or "", "source": c.get("source") or "",
                    "note": (c.get("note") or "")[:1].upper() + (c.get("note") or "")[1:], **{"src": srcs(c)}})
    cap = []
    for c in O["capex"]:
        if c.get("value") is None:
            cap.append({"entity": c["entity"], "gap": True})
            continue
        cap.append({"entity": c["entity"], "gap": False, "value": bn(c["value"]), "fy": c.get("fy") or "", "status": c.get("status") or "",
                    "label": c.get("label") or "", "share": c.get("share") or "", "part_year": bool(c.get("part_year")), "src": srcs(c)})
    return {"lede": system_lede(O), "rev": rev, "rev_total": {"lower": bn(O["revenue_lower"]), "upper": bn(O["revenue_upper"])},
            "not_disclosed": crc.SYS_NOT_DISCLOSED.format(names=", ".join(O["not_disclosed"])) if O.get("not_disclosed") else "",
            "cap": cap, "cap_total": bn(O["capex_total"]), "note": O.get("note") or "",
            "cap_foot": crc.SYS_CAPEX_FOOT.format(
                periods="; ".join(f"{c['entity']} {c.get('fy')}" for c in O["capex"] if c.get("value") is not None),
                part=(crc.SYS_CAPEX_PART.format(names=", ".join(c["entity"] for c in O["capex"] if c.get("part_year")))
                      if any(c.get("part_year") for c in O["capex"]) else ""))}


def _lead(R: C.Result) -> list[str]:
    S = R.scn["central"]
    P = R.P
    ny = C.next_year(S)
    fav, adv = R.scn["favourable"], R.scn["adverse"]
    parts = [crc.LEAD_1.format(hurdle=hurdle_label(P.hurdle), latest=f"{S.latest['cov1']:.2f}")]
    if ny and ny["cov1"] is not None and ny["lam"] is not None:
        if ny["lam"] >= 1:
            parts.append(crc.LEAD_2_SHORT.format(next=f"{ny['cov1']:.2f}", rise=f"{(ny['lam'] - 1) * 100:.0f}%"))
        else:
            parts.append(crc.LEAD_2_OVER.format(next=f"{ny['cov1']:.2f}", fall=f"{(1 - ny['lam']) * 100:.0f}%"))
        nf, na = C.next_year(fav), C.next_year(adv)
        parts.append(crc.LEAD_RANGE.format(latest_adv=fx(adv.latest["cov1"]), latest_fav=fx(fav.latest["cov1"]),
                                           next_adv=fx(na["cov1"] if na else None), next_fav=fx(nf["cov1"] if nf else None)))
    else:
        parts.append(crc.LEAD_2_NA)
    parts.append(crc.LEAD_HURDLE)
    if P.toggle:
        parts.append(crc.LEAD_MEMO)
    return parts


def _cards(R: C.Result) -> list[dict]:
    sc = {s: R.scn[s] for s in C.SCN}
    h = hurdle_label(R.P.hurdle)

    def trio(fn):
        return {s: fn(sc[s]) for s in C.SCN}

    def rng(vals):
        return f"Favourable {vals['favourable']} · Adverse {vals['adverse']}"

    def ph(y):
        if not y or y["lam"] is None:
            return "n/a"
        return f"+{(y['lam'] - 1) * 100:.0f}%" if y["lam"] >= 1 else f"could fall {(1 - y['lam']) * 100:.0f}%"
    latest = trio(lambda S: fx(S.latest["cov1"]))
    nxt = trio(lambda S: fx((C.next_year(S) or {}).get("cov1")))
    be = trio(_be_text)
    ltm = trio(lambda S: fx(S.ltm["cov1"]) if S.ltm else "n/a (gap)")
    ltm_c = sc["central"]
    ny = {s: C.next_year(sc[s]) for s in C.SCN}
    rev0 = sc["central"].forecast.fc["years"][0]["revenue"] if sc["central"].forecast else None
    cen = ny["central"] if ny["central"] and ny["central"]["lam"] is not None else None
    rev_sub = ""
    if cen:
        rev_sub = (f"{ph(cen)} on the latest fiscal year's {usd_bn(rev0)}. Favourable {ph(ny['favourable'])}, adverse {ph(ny['adverse'])}.")
    ly = sc["central"].forecast.labels[0] if sc["central"].forecast else ""
    return [
        {"label": crc.K_LATEST, "value": latest["central"], "unit": "of the requirement", "sub": rng(latest), "help": crc.K_LATEST_HELP,
         "source": "1.00x = the hurdle"},
        {"label": crc.K_NEXT, "value": nxt["central"], "unit": "of the requirement", "sub": rng(nxt), "help": crc.K_NEXT_HELP,
         "source": f"{ly}; 1.00x = the hurdle" if ly else None},
        {"label": crc.K_LTM, "value": ltm["central"], "unit": "of the requirement" if ltm_c.ltm else "",
         "sub": (rng(ltm) + ". " + ltm_label(ltm_c)) if ltm_c.ltm else (ltm_why_all(ltm_c) or "last-twelve-months figures are a gap in the inputs"),
         "help": crc.K_LTM_HELP, "source": "1.00x = the hurdle"},
        {"label": crc.K_BREAKEVEN, "value": be["central"], "unit": "after-tax return", "sub": rng(be), "help": crc.K_BREAKEVEN_HELP,
         "source": f"vs the {h} hurdle in force"},
        {"label": crc.K_REVENUE, "value": usd_bn(cen["revenue_needed"]) if cen else "n/a", "unit": "a year", "sub": rev_sub, "help": crc.K_REVENUE_HELP,
         "source": f"{ly}, at a {h} return" if ly else None},
    ]


def _ltm_cell(p: dict | None) -> dict:
    if not p or p.get("cov") is None:
        return {"cov": "n/a (gap)", "to": "", "title": (p or {}).get("why") or "last-twelve-months figures are a gap in the inputs", "gap": True}
    title = (f"{p['from']} to {p['to']}: " if p.get("from") and p.get("to") else "") + f"contribution {bn(p['C'])} / requirement {bn(p['req'])} US$ bn"
    return {"cov": fx(p["cov"]), "to": "to " + ltm_end_text(p), "title": title, "gap": False}


def _ltm_fy_note(S: C.Scenario) -> str:
    """Companies whose LTM window is their latest fiscal year (no later quarter is filed), from the inputs' own windows."""
    names = [b.name for b in S.cloud if b.ltm_window and b.ltm_window.get("end") is not None and abs(b.ltm_window["end"] - b.last.end) < 1e-6]
    if not names:
        return ""
    one = len(names) == 1
    return " " + crc.LTM_NOTE_FY.format(names=", ".join(names), has="has" if one else "have", its="its" if one else "their")


def _entity_rows(S: C.Scenario) -> tuple[list[dict], dict]:
    nye = C.entity_next_year(S)
    rows, sums = [], {"rev": 0.0, "rent": 0.0, "c": 0.0, "req": 0.0}
    for b in S.cloud:
        r, f = b.last, b.last.flow
        per = S.latest["per_entity"][b.name]
        rent_shown = f.rent if S.include_rent else 0
        sums["rev"] += f.revenue
        sums["rent"] += rent_shown
        sums["c"] += per["C"]
        sums["req"] += per["req"]
        chips, flags = _chips(r, S)
        ny = nye.get(b.name)
        rows.append({"name": b.name, "fy": r.fy, "revenue": bn(f.revenue), "rent_gap": r.rent_gap and S.include_rent,
                     "rent": ("−" + bn(f.rent)) if S.include_rent and not r.rent_gap else "", "rent_off": not S.include_rent,
                     "contribution": bn(per["C"]), "req": bn(per["req"]),
                     "cov": fx(per["C"] / per["req"] if per["req"] > 0 else None),
                     "next": fx(ny["cov1"]) if ny else "n/a", "ltm": _ltm_cell(S.ltm_per.get(b.name)), "share": _share_text(b),
                     "chips": chips, "flags": flags})
    total_ny = None
    if S.forecast and nye:
        tc = sum(v["C"] for v in nye.values() if v)
        tr = sum(v["req"] for v in nye.values() if v)
        total_ny = tc / tr if tr > 0 else None
    total = {"revenue": bn(sums["rev"]), "rent": ("−" + bn(sums["rent"])) if S.include_rent else "", "contribution": bn(sums["c"]),
             "req": bn(sums["req"]), "cov": fx(S.latest["cov1"]), "next": fx(total_ny),
             "ltm": ({"cov": fx(S.ltm["cov1"]), "note": "total, own windows", "why": None} if S.ltm else
                     {"cov": "n/a (gap)", "note": "", "why": ltm_why_all(S)})}
    return rows, total


def _coverage_chart(R: C.Result):
    S = R.act
    cen = R.scn["central"]
    series = {s: R.scn[s].series for s in C.SCN}
    cut = cen.opening_cutoff
    first = cen.series[0]["year"] if cen.series else None
    shade = {"x1": cut + 0.5} if (cut is not None and first is not None and cut >= first) else None
    recent = [p["cov"] for s in C.SCN for p in series[s] if p["cov"] is not None and (cut is None or p["year"] > cut + 1)]
    y_cap = max(1.5, max(recent) * 1.25) if (shade and recent) else None
    notes = {"shade": None, "counts": ", ".join(f"FY{p['year']}: {p['n']}" for p in cen.series),
             "left": ", ".join(f"FY{y}" for y in cen.series_left_out)}
    if shade:
        runoff = max(b.ent["opening"]["at"] + R.P.life_it / 2 for b in cen.cloud if C.opening_amount(b.ent.get("opening"), b.key) > 0)
        notes["shade"] = crc.CHART_NOTE_SHADE.format(first=first, cut=cut, runoff=round(runoff), after=cut + 1)
    fig = ct.both(lambda t: fcm.fig_coverage(t, series, y_cap, shade, S.scn))
    legend = [{"name": fcm.SCN_NAME[s], "dark": fcm.scn_color(s, "dark"), "light": fcm.scn_color(s, "light"), "dash": "solid"}
              for s in ("favourable", "central", "adverse")]
    legend.append({"name": "1.00x: the capital earns exactly the hurdle (after-tax, unlevered)", "dark": ct.palette("dark")["muted"],
                   "light": ct.palette("light")["muted"], "dash": "dot"})
    return {"fig": fig, "legend": legend, "notes": notes, "empty": not cen.series}


def _consensus(S: C.Scenario, data: dict):
    """Consensus by entity, from the inputs: {name: {year: row}}."""
    out = {}
    for p in S.forecast.per:
        ent = next((e for e in data["entities"] if e["name"] == p.name), None)
        cons = ((ent or {}).get("forecast") or {}).get("consensus") or []
        if cons:
            out[p.name] = {C.fy_year(c["fy"]): c for c in cons}
    return out


def _forecast(R: C.Result, data: dict) -> dict:
    S = R.act
    F = S.forecast
    if not F:
        return {"empty": True}
    ys = F.fc["years"]
    cats = ["Latest FY"] + [y["label"] for y in ys[1:]]
    capital = [y["req"] / 1000 for y in ys]
    existing = [(y["rent"] - y["added_rent"]) / 1000 for y in ys]
    committed = [y["added_rent"] / 1000 for y in ys]
    pre = [y["rev_pre"] / 1000 for y in ys]
    tot_committed = sum(y["added_rent"] for y in ys)
    run_rate = sum(p.added[-1] for p in F.per if p.added)
    annual_full = sum(p.lnc["total"] / p.term.years for p in F.per if p.lnc)
    cons = _consensus(S, data)
    rows = []
    for i, y in enumerate(ys):
        lam = y["lam"]
        grow = (lam - 1) if lam is not None else None
        ann = (lam ** (1 / i) - 1) if (i > 0 and lam is not None and lam > 0) else None
        rows.append({"hist": i == 0, "label": "Latest FY (actual)" if i == 0 else y["label"], "req": bn(y["req"]),
                     "rent": bn(y["rent"] - y["added_rent"]), "committed": bn(y["added_rent"]), "pre": bn(y["rev_pre"]), "cov": fx(y["cov1"]),
                     "needed": bn(y["revenue_needed"]), "grow": spct(grow) + (" headroom" if grow is not None and grow < 0 else ""),
                     "per_year": "" if i == 0 else spct(ann, 1)})
    # consensus detail table
    crows = []
    for p in F.per:
        m = cons.get(p.name)
        if not m:
            crows.append({"co": p.name, "none": True})
            continue
        prev = None
        for yr in sorted(m):
            c = m[yr]
            k = yr - p.latest_year
            need = ys[k]["lam"] * p.rev_last if (1 <= k <= F.n and ys[k]["lam"]) else None
            g = (c["revenue"] / prev["revenue"] - 1) if (prev and prev["revenue"] > 0) else None
            crows.append({"co": p.name, "scope": "whole-company consensus", "fy": c["fy"], "revenue": bn(c["revenue"]), "growth": spct(g, 1),
                          "ebitda": bn(c.get("ebitda")) if c.get("ebitda") is not None else "n/a",
                          "analysts": str(c["n_analysts"]) if c.get("n_analysts") is not None else "n/a",
                          "need": bn(need) if need is not None else "–",
                          "need_vs": spct(need / p.rev_last - 1) if need is not None else "–", "none": False})
            prev = c
    # capex per entity
    cap = []
    for p in F.per:
        cells = []
        for j, bs in enumerate(p.basis):
            if bs["kind"] == "guided":
                if bs.get("assumed"):
                    kind = f"assumption from {bs['from']} guidance ({round(bs['overlap'] * 100)}% of this fiscal year)"
                else:
                    kind = "guided" + (f" ({bs['from']})" if bs.get("from") and bs["from"] != bs["fy"] else "")
            elif bs["kind"].startswith("stub actual"):
                kind = bs["kind"]
            else:
                kind = "flat (assumption)"
            stub = ""
            if bs.get("stub"):
                st = bs["stub"]
                stub = (f"full year = {'stub actual' if st['amount'] >= st['planned'] - 1e-9 else 'guided/flat ' + bn(st['planned'])}; "
                        f"includes {st['label']} actual {bn(st['amount'])} (kept in the history) + remainder {bn(bs['remainder'])} over the rest of the year")
            stmt = ""
            if bs.get("assumed") and (bs.get("statement") or bs.get("note")):
                s = bs.get("statement")
                stmt = "Company statement: " + (s if isinstance(s, str) else (s.get("text") or s.get("note") or "") if s else str(bs["note"])[:220])
            cells.append({"value": bn(p.capex[j]), "fy": bs["fy"], "kind": kind, "guided": bs["kind"] == "guided", "stub": stub, "stmt": stmt})
        cap.append({"name": p.name, "cells": cells})
    # leases not yet commenced
    lrows = []
    for p in F.per:
        l = p.lnc
        if not l:
            lrows.append({"name": p.name, "none": True})
            continue
        ok = l.get("from") is not None and l.get("to") is not None
        lrows.append({"name": p.name, "none": False, "total": bn(l["total"]),
                      "scaled": bn(p.lnc_used) if abs(p.lnc_used - l["total"]) > 1e-6 else "", "scope": l.get("scope") or "",
                      "window": f"{month_year(l['from'])} to {end_month_year(l['to'])}" if p.lnc_ok else "window not disclosed: not in the band",
                      "term": _term_text(l), "term_used": f"{p.term.years:.1f} yr", "annual": bn(p.lnc_used / p.term.years) if p.lnc_ok else "–"})
    floor_for = [f"{p.name} (${bn(p.lnc['total'])}bn)" for p in F.per if p.lnc and not p.lnc_ok]
    guided_srcs = []
    for p in F.per:
        for bs in p.basis:
            if bs["kind"] == "guided":
                guided_srcs.append(f"{p.name} {bs['fy']}: " + "; ".join(dcm.resolve_src(s)["text"] for s in (bs.get("src") or [])[:1]))
    fig = ct.both(lambda t: fcm.fig_forecast(t, cats, capital, existing, committed, pre))
    bc = {t: fcm.band_colors(t) for t in ct.THEMES}
    legend = [
        {"name": "Capital requirement (annual return on capex in service)", "dark": bc["dark"]["capital"], "light": bc["light"]["capital"]},
        {"name": "Operating rent already in place", "dark": bc["dark"]["rent"], "light": bc["light"]["rent"]},
        {"name": "Committed rent from leases not yet commenced: " + crc.FC_COMMITTED_LEGEND.format(
            total=bn(tot_committed), run=bn(run_rate), last=ys[-1]["label"], full=bn(annual_full)),
         "dark": bc["dark"]["committed"], "light": bc["light"]["committed"]},
        {"name": "Cash earned before rent at the latest fiscal year's revenue", "dark": bc["dark"]["mark"], "light": bc["light"]["mark"], "dash": "solid"},
    ]
    return {"empty": False, "fig": fig, "legend": legend, "rows": rows, "cons_rows": crows, "capex": cap, "capex_years": F.n,
            "lnc": lrows, "lnc_floor": floor_for, "guided": guided_srcs, "horizon": F.horizon, "latest_rev": usd_bn(ys[0]["revenue"]),
            "committed_total": bn(tot_committed), "cons_any": bool(cons)}


def _term_text(l: dict) -> str:
    if l.get("term_min") is not None and l.get("term_max") is not None:
        return f"{l['term_min']}–{l['term_max']} yr"
    if l.get("term_avg") is not None:
        return f"average {l['term_avg']} yr"
    if l.get("term_max") is not None:
        return f"up to {l['term_max']} yr"
    return f"not disclosed ({C.DEFAULT_TERM} yr assumed)"


def _leases(R: C.Result) -> dict:
    S, P = R.act, R.P
    l1 = []
    for b in S.cloud:
        r, f = b.last, b.last.flow
        pre = f.revenue * f.m_pre
        rent_o = r.y.get("rent")
        l1.append({"name": b.name, "fy": r.fy, "revenue": bn(f.revenue), "pre": bn(pre), "gap": r.rent_gap,
                   "rent": bn(f.rent), "share": pct(f.rent / f.revenue, 1) if (not r.rent_gap and f.revenue > 0) else "n/a",
                   "after": bn(pre - f.rent), "status": (rent_o or {}).get("status") or "gap",
                   "source": "; ".join(dict.fromkeys(dcm.resolve_src(s)["text"] for s in ((rent_o or {}).get("src") or [])[:1])),
                   "note": (rent_o or {}).get("note") or ""})
    l2 = []
    for b in S.built:
        any_ = False
        for r in b.rows:
            o = r.y.get("op_lease_rou_excluded")
            if not o:
                continue
            any_ = True
            l2.append({"name": b.name, "fy": r.fy, "capex": bn(r.capex), "op": "gap" if r.op_gap else bn(r.op_lease), "gap": r.op_gap,
                       "reason": crc.L2_REASON_INDIRECT if b.role == "indirect" else crc.L2_REASON_CLOUD, "status": o.get("status") or ""})
        if not any_:
            l2.append({"name": b.name, "fy": "", "capex": "–", "op": "–", "gap": False, "none": True,
                       "reason": "No operating-lease additions in the inputs" + (" (entity excluded from totals)" if b.role == "memo" else ""), "status": ""})
    l4 = []
    for b in S.cloud:
        pb, pm = S.base["per_entity"][b.name], S.memo["per_entity"][b.name]
        cb = pb["C"] / pb["req"] if pb["req"] > 0 else None
        cm = pm["C"] / pm["req"] if pm["req"] > 0 else None
        l4.append({"name": b.name + (" (not in the memo)" if b.memo_excluded else ""), "c0": bn(pb["C"]), "r0": bn(pb["req"]), "x0": fx(cb),
                   "c1": bn(pm["C"]), "r1": bn(pm["req"]), "x1": fx(cm),
                   "d": (f"{cm - cb:+.2f}x".replace("-", "−")) if (cb is not None and cm is not None) else "n/a"})
    tot = {"c0": bn(S.base["C"]), "r0": bn(S.base["req"]), "x0": fx(S.base["cov1"]), "c1": bn(S.memo["C"]), "r1": bn(S.memo["req"]),
           "x1": fx(S.memo["cov1"]), "d": f"{S.memo['cov1'] - S.base['cov1']:+.2f}x".replace("-", "−")}
    excl = [b.name for b in S.cloud if b.memo_excluded]
    read = crc.L4_READ.format(hurdle=pct(P.hurdle, 1), be_base="n/a" if S.base_breakeven is None else pct(S.base_breakeven, 1),
                              be_memo="n/a" if S.memo_breakeven is None else pct(S.memo_breakeven, 1))
    terms = "; ".join(f"{b.name} {b.term.years:.1f} yr ({b.term.basis})" for b in S.cloud)
    return {"l1": l1, "l2": l2, "l4": l4, "l4_total": tot, "read": read, "terms": crc.L4_TERMS.format(terms=terms),
            "excluded": crc.L4_EXCLUDED.format(names=", ".join(excl)) if excl else ""}


def _circular(R: C.Result, data: dict) -> dict:
    rows = []
    for r in R.circ["rows"]:
        c = r["c"]
        tail = []
        if c.get("revenue_from_period"):
            tail.append(f"Revenue period: {c['revenue_from_period']}.")
        if c.get("formula"):
            tail.append(f"Derived as {c['formula']}.")
        if c.get("note"):
            tail.append(c["note"])
        who = f"{c.get('funder')} → {c.get('counterparty')}"
        srcs = "; ".join(dict.fromkeys(dcm.resolve_src(s)["text"] for s in (c.get("src") or [])))
        if r["gap"]:
            rows.append({"who": who, "rev": "–", "funded": "–", "as_of": "n/a", "gap": True, "treat": "No amount is filed; no number is shown.",
                         "tail": " ".join(tail), "status": "gap", "src": srcs})
            continue
        if r["applied"]:
            treat = (f"Netted (same period): revenue booked in the latest fiscal year removed at {r['entity']}'s {pct(r['m'], 0)} pre-rent margin "
                     f"= ${bn(r['removed'])}bn of contribution.")
        else:
            treat = "Not netted: " + ("no filed revenue from this customer to remove." if r["mode"] == "same_period"
                                      else "the funding is a dated cumulative amount that post-dates the flow period, so it is listed, not subtracted.")
        rows.append({"who": who, "rev": bn(c["revenue_from"]) if c.get("revenue_from") is not None else "not filed",
                     "funded": bn(c["funded_cum"]) if c.get("funded_cum") is not None else "–", "as_of": c.get("as_of") or "n/a", "gap": False,
                     "treat": treat, "tail": " ".join(tail), "status": c.get("status") or "", "src": srcs})
    stress = []
    for s in C.SCN:
        Q = C.compute_circular(data, R.scn[s], R.P)
        ents = "; ".join(f"{e['name']} {fx(e['cov_with'])} → {fx(e['cov_without'])}" for e in Q["entities"])
        stress.append({"name": fcm.SCN_NAME[s], "central": s == "central", "with": fx(Q["cov_with"]), "without": fx(Q["cov_without"]),
                       "removed": bn(Q["removed"]), "ents": ents})
    return {"rows": rows, "stress": stress}


def _ind_lead(R: C.Result) -> str:
    names = [i["name"] for i in R.act.indirect]
    if not names:
        return ""
    return crc.IND_LEAD.format(names=", ".join(names), has="has" if len(names) == 1 else "have", hurdle=hurdle_label(R.P.hurdle))


def _indirect(R: C.Result) -> list[dict]:
    out = []
    for I in R.act.indirect:
        rows = [{"fy": r["fy"], "capex": bn(r["capex"]), "req": bn(r["req"])} for r in I["rows"]]
        ltm = {"label": I["ltm"]["label"], "req": bn(I["ltm"]["req"])} if I["ltm"] else None
        out.append({"name": I["name"], "rows": rows, "ltm": ltm})
    return out


def _params_rows(R: C.Result) -> list[dict]:
    P = R.P
    return [
        {"k": "Hurdle", "v": pct(P.hurdle, 1), "n": "The after-tax unlevered return the capital must earn; the requirement is the pre-tax cash that delivers it"},
        {"k": "IT economic life", "v": f"{P.life_it:g} yr", "n": "Replacement follows obsolescence"},
        {"k": "Facilities life", "v": f"{P.life_fac:g} yr", "n": "Assumption"},
        {"k": "Build lag, IT / facilities", "v": f"{P.lag_it:g} / {P.lag_fac:g} yr", "n": "Assumption; compare each company's construction-in-progress ratio in the register"},
        {"k": "Tax rate", "v": pct(P.tax, 0), "n": "Applied to profitable groups; 0% for loss-makers (assumption)"},
        {"k": "Bonus depreciation", "v": "on" if P.bonus else "off", "n": "For vintages after 19 Jan 2025"},
        {"k": "Allocation scenario shown in detail", "v": fcm.SCN_NAME[P.scenario], "n": {
            "favourable": "for each company, the allocation share that gives it the highest coverage",
            "central": "the middle allocation share for every company",
            "adverse": "for each company, the allocation share that gives it the lowest coverage"}[P.scenario]},
        {"k": "Operating leases", "v": "rent deducted" if not P.toggle else "memo: as capex", "n": "Never both"},
    ]


def _v4(R: C.Result) -> dict:
    rows = [{"life": f"{o['life']} yr", "label": crc.V4_LABELS.get(o["life"], ""), "fav": fx(o["cov"]["favourable"]),
             "cen": fx(o["cov"]["central"]), "adv": fx(o["cov"]["adverse"]), "ltm": None} for o in R.sens]
    flips = any((o["cov"]["central"] >= 1) != (R.sens[0]["cov"]["central"] >= 1) for o in R.sens)
    return {"rows": rows, "note": crc.V4_FLIPS if flips else crc.V4_STABLE}


def _showing(f: dict, P: C.Params) -> str:
    """One sentence naming every control's setting, under the controls."""
    return (f"Showing the {fcm.SCN_NAME[P.scenario].lower()} scenario in detail; hurdle {hurdle_label(P.hurdle)}, IT life {P.life_it:g} years, "
            f"facilities {P.life_fac:g} years, build lags {P.lag_it:g} and {P.lag_fac:g} years, tax {P.tax * 100:g}%, "
            f"bonus depreciation {f['bonus']}, operating leases {'as capex (memo)' if P.toggle else 'as rent (filed)'}, "
            f"lease term {'the longest disclosed' if P.lease_pick == 'max' else 'the midpoint'}.")


def crm_results(f: dict) -> dict:
    data = dcm.inputs()
    if data is None:
        return {"f": f, "empty": crc.NO_DATA}
    P = params_of(f, data)
    R = C.compute_cached(data, P)
    S = R.act
    rows, total = _entity_rows(S)
    memos = [e for e in data["entities"] if e["role"] == "memo"]
    buyers = [b.name for b in S.cloud if any(r.rev_memo > 0 for r in b.rows)]
    gross_note = (crc.ENT_NOTE_GROSS.format(gross=bn(S.totals["gross"]), net=bn(S.totals["net"]), buyers=", ".join(buyers))
                  if S.totals["revenue_memo"] > 0 and buyers else "")
    build = crc.BUILD_BODY.format(life_it=f"{P.life_it:g}", lag_it=f"{P.lag_it:g}", life_fac=f"{P.life_fac:g}", lag_fac=f"{P.lag_fac:g}",
                                  hurdle=pct(P.hurdle, 1), tax=pct(P.tax, 0),
                                  bonus=", 100% bonus depreciation for vintages after 19 Jan 2025" if P.bonus else "")
    return {
        "f": f, "empty": None, "P": P, "lead": _lead(R), "cards": _cards(R), "toggle": P.toggle, "scenario_name": fcm.SCN_NAME[P.scenario],
        "ent_rows": rows, "ent_total": total, "ent_note_gross": gross_note,
        "ent_note_memo": crc.ENT_NOTE_MEMO_ENTITIES.format(items="; ".join(
            f"{e['name']}: {(e.get('memo') or {}).get('reason') or (e.get('notes') or ['see inputs'])[0]}" for e in memos)) if memos else "",
        "ent_loss": any(r["next"] == "n/a" or r["cov"].startswith("-") or r["cov"].startswith("−") for r in rows),
        "scenario_notes": _scenario_notes(R, data), "build": build, "chart": _coverage_chart(R),
        "forecast": _forecast(R, data), "leases": _leases(R), "circular": _circular(R, data), "indirect": _indirect(R), "ind_lead": _ind_lead(R),
        "params": _params_rows(R), "v4": _v4(R), "ltm_note": (crc.LTM_NOTE_ON.format(label=ltm_label(R.scn["central"])) + _ltm_fy_note(R.scn["central"]) if R.scn["central"].ltm
                     else crc.LTM_NOTE_OFF.format(why=ltm_why_all(R.scn["central"]))),
        "system": _system(data),
        "hurdle_label": hurdle_label(P.hurdle), "showing": _showing(f, P),
        "controls": _controls(f),
    }


# --------------------------------------------------------------------------- the inputs register (not driven by the controls)

def _rng_text(o: dict, unit: str = "USD m") -> str:
    r = C.range_of(o)
    if r.gap:
        return "gap"
    if r.low == r.mid == r.high:
        return num(r.mid, 0) if abs(r.mid) >= 100 else f"{r.mid:,.3g}"
    return f"{num(r.low, 0)} / {num(r.mid, 0)} / {num(r.high, 0)}"


def _item(entity, period, item, o, unit="USD m") -> dict | None:
    if not o:
        return None
    srcs = [dcm.resolve_src(s) for s in (o.get("src") if isinstance(o.get("src"), list) else [o.get("src")] if o.get("src") else [])]
    texts = list(dict.fromkeys(("Method note: " + s["text"].removeprefix("Method note: ")) if s["kind"] == "method" else s["text"] for s in srcs))
    accs = list(dict.fromkeys(s["accession"] for s in srcs if s["accession"]))
    link = next((s["link"] for s in srcs if s["link"]), None)
    pubs = [s["published"] for s in srcs if s["published"]]
    return {"entity": entity, "period": period, "item": item, "value": _rng_text(o) if C.has_val(o) else "gap", "unit": unit,
            "status": o.get("status") or "", "how": o.get("formula") or o.get("note") or "",
            "source": " · ".join(texts) if texts else "(no filing: a labelled assumption or a gap)",
            "accession": "; ".join(accs), "published": max(pubs) if pubs else "", "link": link,
            "method": any(s["kind"] == "method" for s in srcs)}


def register_rows() -> list[dict]:
    data = dcm.inputs()
    if data is None:
        return []
    out = []
    for e in data["entities"]:
        n = e["name"]
        out.append(_item(n, "latest", "IT share of capex", {"value": e["s_it"]["value"] * 100, "status": e["s_it"].get("status"),
                                                             "src": e["s_it"].get("src"), "formula": e["s_it"].get("source")}, "%") if e.get("s_it") else None)
        cip = e.get("cip_ratio")
        if cip:
            out.append(_item(n, cip.get("as_of") or "", "Construction in progress / gross PP&E", dict(cip, value=cip["value"] * 100), "%"))
        op = e.get("opening")
        if op:
            out.append(_item(n, month_year(op["at"]), "Opening stock (net PP&E)", op))
        for y in e.get("years") or []:
            for key, label in (("revenue", "Revenue"), ("contribution", "Contribution (cash margin before D&A, after rent)"),
                               ("rent", "Operating rent"), ("capex", "Capex incl. finance leases"),
                               ("op_lease_rou_excluded", "Operating-lease additions (excluded)")):
                out.append(_item(n, y["fy"], label, y.get(key)))
        st = e.get("stub")
        if st:
            out.append(_item(n, st.get("label") or "stub", "Capex incl. finance leases", st.get("capex")))
            out.append(_item(n, st.get("label") or "stub", "Operating-lease additions (excluded)", st.get("op_lease_rou_excluded")))
        lt = e.get("ltm") or {}
        for key, label in (("revenue", "Revenue"), ("contribution", "Contribution (cash margin before D&A, after rent)"), ("rent", "Operating rent")):
            out.append(_item(n, lt.get("label") or "LTM", label, lt.get(key)) if lt.get(key) and C.has_val(lt[key]) else None)
        fc = e.get("forecast") or {}
        for g in fc.get("capex_guided") or []:
            out.append(_item(n, g.get("fy") or "", "Capex guidance (scoped to this entity)", g))
        l = fc.get("lnc")
        if l and l.get("total") is not None:
            out.append(_item(n, "latest", "Leases not yet commenced (company total)", {"value": l["total"], "status": "filed", "src": l.get("src"),
                                                                                         "formula": l.get("scope")}))
            if l.get("scaled"):
                out.append(_item(n, "latest", "Leases not yet commenced (scaled by share)", l["scaled"]))
        for c in fc.get("consensus") or []:
            out.append(_item(n, c["fy"], "Analyst consensus revenue (whole company)", {"value": c.get("revenue"), "status": c.get("status") or "estimate",
                                                                                         "src": c.get("src")}))
    O = data.get("system_overlay") or {}
    for c in O.get("revenue") or []:
        if c.get("value") is not None:
            out.append(_item("System memo", c.get("as_of") or "", "AI revenue: " + c["component"], c))
    for c in O.get("capex") or []:
        if c.get("value") is not None:
            out.append(_item("System memo", c.get("fy") or "", "Capex: " + c["entity"], c))
    return [r for r in out if r]


REGISTER = register(TableDef(
    id="crm_register", title=crc.REGISTER_TITLE,
    cols=(Col("entity", "Entity", "mono"), Col("period", "Period", "mono"), Col("item", "Figure"), Col("value", "Value (low / mid / high)", "mono"),
          Col("unit", "Unit"), Col("status", "Status"), Col("how", "How derived", "long"), Col("source", "Source (filing)", "long"),
          Col("accession", "Accession", "mono"), Col("published", "Published", "mono"), Col("link", "Filing", "link")),
    default_cols=("entity", "period", "item", "value", "unit", "status", "source", "accession", "link"),
    rows=register_rows, subtitle=crc.REGISTER_SUB, natural=True, noun=("figure", "figures"), source=crc.REGISTER_FOOT,
))


def crm_static() -> dict:
    data = dcm.inputs()
    if data is None:
        return {"empty": crc.NO_DATA}
    notes = [{"name": e["name"], "role": e["role"], "notes": e.get("notes") or [],
              "breaks": [f"{s.get('label')}: {s.get('detail')}" for s in (e.get("series_breaks") or [])]} for e in data["entities"]
             if (e.get("notes") or e.get("series_breaks"))]
    return {"empty": None, "register": table_view("crm_register"), "notes": notes, "gaps": data.get("gaps") or [],
            "generated": (data.get("generated") or "")[:10], "facts_max": dcm.facts_published_max()}


def capex_return_model(f: dict) -> dict:
    return {"c": crc, "f": f, "results": crm_results(f), "static": crm_static()}
