"""Data for the AI capex return model: committed files only, read-only.

Two files, both under the data root (`config.DATA_DIR`), none read anywhere else:

- data/processed/capex_model_inputs.json   the model's inputs (every figure carries a status and `src` keys)
- data/reference/capex_model_facts.csv     the filed rows those keys name (entity|metric|period_start|period_end)

The model repo's exporter writes them; this app never changes them. Both are shipped to the public site with the
model's source for its sliders (app/capex_model/live.py), so no other page's files are read here.
"""
from __future__ import annotations

import csv
import json
import re
from functools import lru_cache
from pathlib import Path

from app.config import DATA_DIR

REF = DATA_DIR / "reference"
PROCESSED = DATA_DIR / "processed"
INPUTS_PATH = PROCESSED / "capex_model_inputs.json"
FACTS_PATH = REF / "capex_model_facts.csv"


def _csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


@lru_cache(maxsize=1)
def inputs() -> dict | None:
    """The model's inputs JSON, or None when the data root does not carry it (an honest empty state)."""
    if not INPUTS_PATH.exists():
        return None
    return json.loads(INPUTS_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def facts() -> dict[str, list[dict]]:
    """The filed rows, by key `entity|metric|period_start|period_end` (a key can carry several rows)."""
    out: dict[str, list[dict]] = {}
    for r in _csv(FACTS_PATH):
        out.setdefault("|".join((r["entity"], r["metric"], r["period_start"], r["period_end"])), []).append(r)
    return out


def facts_published_max() -> str | None:
    d = [r["published_date"] for rows in facts().values() for r in rows if r.get("published_date")]
    return max(d) if d else None


# --------------------------------------------------------------------------- resolving a `src` key

_SUB = re.compile(r"@(sub\d+)$")
_URL = re.compile(r"https?://[^\s;,)]+")
_ACCESSION = re.compile(r"^\d{10}-\d{2}-\d{6}$")
_CITATION = re.compile(r"^[^()]*\((\d{10}-\d{2}-\d{6})\),")


def edgar_search(accession: str) -> str:
    """The EDGAR full-text search URL for an accession number (the same link the model's own page used)."""
    return f"https://www.sec.gov/edgar/search/#/q=%22{accession}%22"


def first_url(text: str | None) -> str | None:
    m = _URL.search(text or "")
    return m.group(0).rstrip(".") if m else None


def link_for(accession_or_url: str | None) -> str | None:
    """A link for an accession number (EDGAR search) or a URL; None for anything else."""
    a = (accession_or_url or "").strip()
    if _ACCESSION.match(a):
        return edgar_search(a)
    return first_url(a)


def resolve_src(src: str) -> dict:
    """What one `src` string of the inputs JSON points at.

    kind `fact`      a key into capex_model_facts.csv: the filing, its accession, publication date and status;
         `guidance`  a row of the dashboard's capex guidance file;
         `citation`  a filing cited in words with its accession number ("Nebius 20-F FY2025 (0001104659-26-052948), Note 7 ...");
         `consensus` an analyst-estimate snapshot;
         `method`    a note from the model's working papers (not a public source; shown as a method note);
         `unresolved` a key the facts file does not hold (listed, never hidden).
    """
    s = str(src)
    base = _SUB.sub("", s)
    sub_m = _SUB.search(s)
    sub = sub_m.group(1) if sub_m else None
    rows = facts().get(base)
    if rows:
        want = f"segment_candidates_{sub}.csv" if sub else None
        if want:
            pick = next((r for r in rows if r["origin_file"] == want), rows[0])
        else:
            pick = next((r for r in rows if "_sub" not in r["origin_file"]), rows[0])
        acc = pick.get("accession_or_url") or ""
        return {"src": s, "kind": "fact", "found": True, "text": pick["source"], "accession": acc,
                "link": link_for(acc), "published": pick.get("published_date") or "", "status": pick.get("status") or "",
                "derivation": pick.get("derivation") or "", "note": pick.get("note") or "",
                "value": pick.get("value") or "", "unit": pick.get("unit") or "", "fiscal_label": pick.get("fiscal_label") or ""}
    out = {"src": s, "kind": "unresolved", "found": False, "text": s, "accession": "", "link": None, "published": "",
           "status": "", "derivation": "", "note": "", "value": "", "unit": "", "fiscal_label": ""}
    if s.startswith("ai-research data/reference/capex_guidance.csv "):
        out.update(kind="guidance", found=True, text="Capex guidance file (capex_guidance.csv), " + s.split("capex_guidance.csv ", 1)[1],
                   status="ir")
    elif s.startswith("FMP analyst-estimates"):
        m = re.match(r"FMP analyst-estimates (\w+) annual, avg, fetched (\d{4}-\d{2}-\d{2})", s)
        out.update(kind="consensus", found=True, status="estimate",
                   text=(f"Analyst consensus (FMP analyst estimates, {m.group(1)}, annual average), fetched {m.group(2)}" if m
                         else "Analyst consensus (FMP analyst estimates)"))
    elif s.startswith("AI-DC dashboard capex guidance table: "):
        out.update(kind="guidance", found=True, status="ir", text="Capex guidance table, " + s.split("table: ", 1)[1])
    elif s.lower().startswith("method note:"):
        out.update(kind="method", found=True, text="Method note: " + s.split(":", 1)[1].strip())
    elif _CITATION.match(s):
        acc = _CITATION.match(s).group(1)
        out.update(kind="citation", found=True, accession=acc, link=edgar_search(acc))
    elif s.startswith("analysis/"):
        tail = s.split("#", 1)[1] if "#" in s else s.split("/")[-1]
        out.update(kind="method", found=True, text=f"Method note: {tail}", status="")
    return out
