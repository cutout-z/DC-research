"""AI capex return model copy.

Authored for this dashboard (no Streamlit source). The model: MODEL_SPEC_v2 of the DC scenario work, ported to
app/capex_model/. Held to the dashboard's rules (measure, don't judge; a number says what it is and what it is
compared with) by tests/test_page_capex_return_model.py.

The unit throughout is US$ (bn = billion, tn = trillion). "Coverage" is a multiple of the requirement.
"""

TITLE = "AI capex return model"
SUBTITLE = ("Do the cloud businesses earn the return the capital they hold requires? A return-on-capital test on filed "
            "figures; revenue is not projected.")

# ---------------------------------------------------------------- lead (computed; placeholders filled by the view)
LEAD_1 = ("At a {hurdle} after-tax return, the cloud capital in service during each company's latest fiscal year earned "
          "{latest} times what it needed.")
LEAD_2_SHORT = ("Capital in place today earns {next} times next year's requirement at today's revenue: revenue would need to rise "
                "{rise}.")
LEAD_2_OVER = ("Capital in place today earns {next} times next year's requirement at today's revenue: revenue could fall "
               "{fall} and still earn the hurdle.")
LEAD_2_NA = "Capital in place today cannot be set against next year's requirement from the inputs held."
LEAD_RANGE = ("Across the favourable and adverse allocation of costs the companies share with other businesses, the first figure "
              "runs from {latest_adv} to {latest_fav} and the second from {next_adv} to {next_fav}.")
LEAD_HURDLE = ("The hurdle is an after-tax, unlevered return: the requirement is the pre-tax cash a year that delivers it once "
               "tax and the build lag are allowed for.")
LEAD_MEMO = ("This view treats operating leases as if they were capex, a memo of how the result would move; it is not the filed "
             "treatment.")

# ---------------------------------------------------------------- controls
CONTROLS_TITLE = "Controls"
SCENARIO_LABEL = "Allocation scenario"
SCENARIO_HELP = ("Companies that report capex, depreciation, rent and leases for the whole company, not the cloud business, need a share "
                 "to be assigned to the cloud business. Favourable and adverse take, for each of them, the share that gives the "
                 "highest and the lowest coverage; central the middle share. This sets the scenario the tables and charts below "
                 "show in detail; the headline cards always show all three.")
HURDLE_LABEL = "Hurdle (after-tax return)"
HURDLE_HELP = "The after-tax, unlevered return the capital must earn. The requirement is the pre-tax cash a year that delivers it."
LIFE_LABEL = "IT equipment economic life"
LIFE_HELP = ("How long servers and networking earn before they are replaced. Replacement follows obsolescence, so this is an "
             "economic life, not the book life. 4 = replaced two GPU generations on (about a 2-year cadence); 5 = midpoint; "
             "6 = close to the book lives most filers use.")
LIFE_FAC_LABEL = "Facilities life"
LIFE_FAC_HELP = "How long buildings, power and cooling earn before they are replaced. An assumption."
LAG_IT_LABEL = "Build lag, IT equipment"
LAG_FAC_LABEL = "Build lag, facilities"
LAG_HELP = ("Years from spending to in service. Capital spent this year earns nothing until it is in service. An assumption; "
            "compare each company's construction-in-progress ratio in the inputs register.")
TAX_LABEL = "Tax rate (profitable groups)"
TAX_HELP = "Applied to profitable groups; loss-makers pay none (an assumption)."
BONUS_LABEL = "Bonus depreciation"
BONUS_HELP = "100% bonus depreciation for vintages placed in service after 19 Jan 2025, which defers tax."
BONUS_OPTIONS = {"on": "On", "off": "Off"}
TERM_LABEL = "Lease term for committed rent"
TERM_HELP = ("Leases signed but not yet started are turned into annual rent at total divided by term. The shortest disclosed term "
             "is not offered: several disclosed minimums are 1 year, which belong to small leases.")
TERM_OPTIONS = {"mid": "Midpoint of the disclosed range", "max": "Longest disclosed"}
RESET = "Reset to defaults"
LIVE_LOADING = "Loading the model into your browser (once, up to 14 MB)."
LIVE_WORKING = "Recalculating."
LIVE_FAILED = "The model could not run in this browser, so the figures below are unchanged."
LEASES_LABEL = "Operating leases"
LEASES_HELP = ("Filed treatment: rent is deducted from contribution. Memo: operating-lease additions are treated as capex "
               "and rent is removed. Rent and the memo are never both applied, so no lease is counted twice.")
LEASES_OPTIONS = {"rent": "Rent deducted (filed)", "capex": "Memo: as capex"}
MEMO_BANNER = ("Memo view: operating leases are treated as capex and operating rent is not deducted. A what-if showing how the "
               "result moves, not the filed treatment.")

# ---------------------------------------------------------------- headline
HEAD_TITLE = "Headline figures"
HEAD_SUB = ("Each figure is for all the cloud businesses together and is shown for the three allocation scenarios. "
            "1.00x means the capital earns exactly the hurdle.")
K_LATEST = "Latest fiscal year: capital in service"
K_LATEST_HELP = ("Contribution divided by requirement, over each company's latest complete fiscal year. Counts only capital that was "
                 "in service during that year: capex spent in it only comes into service after the build lag (set under "
                 "Parameters in force), so the latest surge is not yet in the requirement.")
K_NEXT = "Next year: capital in place today"
K_NEXT_HELP = ("The same ratio for the year after, with the latest spending and next year's capex (guided where the company "
               "guides) in the requirement, and revenue held at the latest fiscal year's level. The earlier year leaves the most "
               "recent surge out; this one counts it.")
K_BREAKEVEN = "Breakeven hurdle"
K_BREAKEVEN_HELP = ("The after-tax unlevered return at which latest-year coverage is exactly 1.00x: the return the capital in "
                    "service actually earned.")
K_REVENUE = "Revenue needed next year"
K_REVENUE_HELP = ("The revenue the cloud businesses together would need next year for coverage of 1.00x at this hurdle, compared "
                  "with their revenue in the latest fiscal year.")
TWO_READINGS = ("**Two readings, equal weight.** The first counts only capital that was in service during the latest fiscal year. "
                "The second adds the capital placed since and next year's capex, with revenue unchanged. Where they differ, the "
                "difference is the recent spending surge.")
K_LTM = "Last twelve months: capital in service"
K_LTM_HELP = ("Coverage over the twelve months to each company's latest quarter: latest fiscal year plus year to date less the same months a "
              "year earlier, for revenue, contribution and rent. The requirement is over the same twelve months. Each company has its own "
              "window, so the total mixes windows that end a few months apart.")
LTM_NOTE_ON = ("**Last twelve months** = latest fiscal year + year to date − the same months a year earlier, for revenue, contribution and rent, "
               "each from filed rows; the requirement is taken over the same twelve months from the capex vintages already in service in them "
               "(the current-year stub included). Each company is measured over its own window ({label}), so the total mixes windows ending a "
               "few months apart.")
LTM_NOTE_FY = ("{names} {has} no quarter filed after the latest fiscal year, so {its} window is that fiscal year.")
LTM_NOTE_OFF = ("Last twelve months is n/a (gap): it needs every cloud company's prior-year year-to-date figures, and a total over only some "
                "companies would mix bases. {why}")

# ---------------------------------------------------------------- entity table
ENT_TITLE = "By company, latest fiscal year and last twelve months"
ENT_SUB = ("Revenue, operating rent as its own deduction, contribution after rent, the requirement on capital in service, and "
           "coverage for the latest fiscal year, for the last twelve months (each company over its own window) and for next year at the "
           "latest fiscal year's revenue.")
ENT_NOTE_STATUS = ("Status of each input: **filed** is read from a filing; **derived** is arithmetic on filed numbers; **allocated** is a "
                   "company-level filed number split by a stated key; **assumption** is a labelled choice; **ir** is company "
                   "guidance or an investor-relations statement.")
ENT_NOTE_GROSS = ("Revenue gross of revenue one cloud books from another: ${gross}bn. Net of that revenue (carried as a memo on the "
                  "rows of {buyers}; not deducted from any contribution, because the buyer's segment operating income already bears "
                  "what it pays): ${net}bn.")
ENT_NOTE_MEMO_ENTITIES = "Left out of every total (memo only): {items}."
ENT_NOTE_LOSS = ("A company whose cash margin before rent is negative earns less than nothing on each dollar of revenue, so no revenue "
                 "level reaches 1.00x; its revenue-needed figure is shown as n/a.")
BUILD_TITLE = "How the requirement is built"
BUILD_BODY = ("Each year's capex plus finance-lease additions is a vintage. It is split into IT equipment (life {life_it} years, build "
              "lag {lag_it} years) and facilities (life {life_fac} years, lag {lag_fac} years). Each part must earn the hurdle "
              "({hurdle}, an after-tax unlevered return) over its life, after tax at {tax} (0% for loss-makers) and the tax depreciation "
              "shield (5-year MACRS for servers{bonus}). The result is an equal annual charge per dollar, applied only while the "
              "asset is in service. Capital in place before the first year in scope is one opening block on its remaining life "
              "(assumption: half the bucket life).")

# ---------------------------------------------------------------- coverage chart
CHART_TITLE = "Coverage by fiscal year"
CHART_SUB = "Contribution ÷ requirement for each fiscal year ending in that calendar year, for the three allocation scenarios."
CHART_FOOT = ("Source: capex_model_inputs.json built from the filings in capex_model_facts.csv; the engine is the model's reference "
              "calculation. Each company is measured over its own fiscal year; companies enter the total when they have data.")
CHART_NOTE_SHADE = ("**The shaded years (FY{first} to FY{cut}) are dominated by an assumption, not by filed data.** Assets bought before "
                    "the first year in scope are carried as one opening block on half their remaining life. The IT part runs off at "
                    "the end of {runoff}, so the requirement falls and coverage jumps (FY{after} is also affected). The vertical axis "
                    "is capped for the later years; a point above it is drawn at the edge and labelled with its value.")
CHART_NOTE_COUNTS = "Companies per year: {counts}."
CHART_NOTE_LEFT = "Left out because not every company has completed the year: {years} (the latest-year figures above include them)."

# ---------------------------------------------------------------- forecast
FC_TITLE = "Forecast to FY{horizon}: what revenue would be needed"
FC_SUB = ("Revenue is not projected. For each future year, the revenue the cloud businesses would need for coverage of 1.00x at this "
          "hurdle, beside analyst consensus where it exists.")
FC_ASSUME = [
    "**Capex:** company guidance for the guided year; after that held flat at the last guided level. The flat level is an assumption, "
    "marked as one wherever it is used. No analyst capex consensus is held in the inputs.",
    "**Revenue:** held at the latest fiscal year, so \"needed\" is relative to today.",
    "**Committed rent:** leases signed but not yet started, phased in evenly over the disclosed start window at total ÷ lease term "
    "(the timing is an assumption). The rent charged in a year is the run-rate at its midpoint. The total is scaled by the company's "
    "allocation share.",
    "**Years:** year 1 is the fiscal year after each company's latest complete one.",
]
FC_CAPEX_CALLOUT_TITLE = "Assumption: capex is held flat after each company's guided year"
FC_CAPEX_CALLOUT = ("Each company's capex is its own guidance for the guided year, then held at that level to the end of the forecast. "
                    "That is an assumption, not a forecast: the one data provider found with analyst capex forecasts (Finnhub) charges "
                    "for them, and no free source carries them, so none are used. If capex keeps rising after the guided year, the "
                    "revenue needed rises with it.")
FC_BARS_TITLE = "What has to be covered each year"
FC_BARS_SUB = ("Capital requirement and operating rent stacked, against the cash the businesses earn before rent at the latest "
               "fiscal year's revenue (the dash). Where the stack is above the dash, today's revenue does not cover the hurdle.")
FC_BARS_FOOT = ("Capex after guidance is held flat (assumption). Committed rent is the separately coloured band: it is rent on leases "
                "signed but not yet commenced, from the filed lease notes.")
FC_COMMITTED_LEGEND = ("US${total}bn of extra rent added across the years shown (the sum of the yearly amounts); run-rate US${run}bn a "
                       "year by {last}; US${full}bn a year once every lease has started")
FC_TABLE_TITLE = "Revenue needed for coverage 1.00x"
FC_TABLE_FOOT = ("Revenue needed is for all the cloud businesses together, each scaling by the same factor. The first row (the latest "
                 "actual year) reproduces the headline coverage. \"Per year\" is the compound yearly rate since the latest fiscal year.")
CONS_TITLE = "Analyst consensus beside the requirement"
CONS_SUB = ("Whole-company figures from analyst consensus. Not like-for-like with the cloud segment revenue the model tests: a "
            "whole company includes its other businesses. Context only; nothing in the requirement uses it.")
CONS_FOOT = ("Source: analyst consensus, annual averages, as held in the inputs file. Analyst counts thin out after the third year. "
             "\"No consensus\" means none was returned for that company.")
CAPEX_TITLE = "Capex used in the forecast, per company"
CAPEX_SUB = "US$ bn a year. Guided years use company guidance; every other year is the flat assumption."
LNC_TITLE = "Leases not yet commenced"
LNC_SUB = "The source of the committed-rent band. US$ bn; the total is company level, the scaled figure is the share used in this scenario."
LNC_NOTE = ("These totals include finance leases, so treating all of it as rent is an upper bound on rent and a lower bound on capex. "
            "Where the total is company-wide it also includes leases outside the cloud business. Without a disclosed start window "
            "an amount cannot be phased, so it is left out of the band, which is then a floor for that company.")

# ---------------------------------------------------------------- leases
LEASE_TITLE = "How operating leases are treated"
LEASE_LEAD = ("Operating leases are not capex here. Their cost is operating rent, deducted inside the margin, so the capital charge does "
              "not count them twice. Finance-lease additions are capex-equivalent and stay in capex. Everything below makes that "
              "visible: **L1** rent as its own deduction, **L2** operating-lease additions listed and excluded, **L3** committed rent "
              "from leases not yet commenced as a separate band, **L4** a memo of the result if operating leases were capex.")
L1_TITLE = "L1. Operating rent as a labelled deduction"
L1_SUB = "Latest fiscal year, selected scenario, US$ bn."
L1_NOTE = ("Allocated rent = the company's operating lease cost × the company's allocation share (the same share as its capex in that "
           "scenario). Rent already sits inside segment operating income; it is "
           "shown as its own line so it is not hidden in one margin percentage.")
L2_TITLE = "L2. Operating-lease additions: listed and excluded"
L2_SUB = "Every fiscal year, selected scenario, US$ bn."
L2_REASON_CLOUD = "its rent is already deducted from the margin (counting it here too would charge it twice)"
L2_REASON_INDIRECT = "operating-lease additions are not capex; their rent is a running cost"
L3_NOTE = "L3. Committed rent from leases not yet commenced is the coloured band in the forecast above, with its own legend entry and total."
L4_TITLE = "L4. Memo: what if operating leases were treated as capex?"
L4_SUB = "Latest fiscal year, selected scenario."
L4_READ = ("**How to read this.** In the memo, each operating-lease addition is annuitised over its lease term at the hurdle and the rent is "
           "taken out of the margin. The change in coverage is the hurdle-minus-lease-rate spread: the memo charges the hurdle ({hurdle}) "
           "on the leased assets where the lease contract charges only its own, lower, implied rate. Breakeven hurdle: {be_base} with "
           "rent deducted, {be_memo} in the memo.")
L4_TERMS = "Lease term used for the memo: {terms}."
L4_EXCLUDED = ("Left out of the memo: {names}. Its rent is not disclosed, so there is no allocated rent to remove and no lease capex is "
               "added; its coverage is the same in both columns.")

# ---------------------------------------------------------------- circular funding, indirect
CIRC_TITLE = "Circular funding (memo)"
CIRC_LEAD = ("Some cloud revenue is paid by AI labs out of money the same cloud invested in them. That revenue is real, but it is not "
             "independent evidence that outside customers value the capacity. This is a stress, not an adjustment: the headline keeps "
             "the revenue.")
CIRC_NOTE = ("Only entries marked \"same period\" are netted: the revenue a cloud booked from its lab customer in its latest fiscal year "
             "is removed from that year's contribution at the cloud's own pre-rent margin. Funding amounts dated after that year are "
             "shown but never subtracted, because they post-date the flow period. Where no amount is filed the row is a gap, not a number.")
IND_TITLE = "Indirect benefit: capital spent for the owner's own use"
IND_LEAD = ("{names} {has} no cloud revenue to test. Capex is shown as a requirement only: **the contribution its own use of the capital must "
            "earn elsewhere** for that capital to meet the {hurdle} hurdle. It is outside the headline.")
IND_NOTE = ("The high-share end of an allocation range assigns all of a company's capex to the cloud, which is the same capital this line "
            "counts for the owner's own use; do not add the two.")

# ---------------------------------------------------------------- system memo
SYS_TITLE = "System view (memo): what end customers pay for AI, beside capex"
SYS_SCOPE = ("This memo is not driven by the controls above: it takes no hurdle, life or allocation scenario, and its figures are the same "
             "whichever are chosen.")
SYS_REV_TITLE = "End-customer AI revenue: stated run-rates and latest full-year figures"
SYS_REV_SUB = "US$ bn a year. The lower bound counts the components marked as counted; the upper bound adds the components marked upper bound only."
SYS_REV_FOOT = "The lower bound has no overlap; the upper bound may double count."
SYS_NOT_DISCLOSED = ("Not disclosed, so not counted and never filled: {names} state no AI revenue figure. Press reports citing unnamed people "
                     "and leaked documents are not used.")
SYS_CAPEX_TITLE = "Capex, latest guided year, by company"
SYS_CAPEX_SUB = "US$ bn. Each company's latest guided year; where a company allocates capex between cloud and its other businesses, the high share."
SYS_CAPEX_FOOT = "Includes non-AI capex. Periods: {periods}.{part}"
SYS_CAPEX_PART = " {names} give no full-year guidance, so only the filed part year is included."
SYS_NOT_RETURN = ("Revenue and capex are not a return test: capex is spent once and earns over several years, and revenue is not profit. "
                  "The headline above is the return test on filed figures.")

# ---------------------------------------------------------------- inputs and sources
INP_TITLE = "Inputs and sources"
INP_LEAD = ("Every figure on the page traces to a row below: its status, how it was derived, and the filing it comes from with the "
            "accession number. Values are US$ million as filed.")
PARAM_TITLE = "Parameters in force"
V4_TITLE = "Does the answer depend on the economic life of IT equipment?"
V4_SUB = "Latest-fiscal-year coverage by IT life, for the three allocation scenarios."
V4_LABELS = {4: "replaced two GPU generations on (about a 2-year cadence)", 5: "midpoint",
             6: "close to the 5 to 6 year book lives most filers use"}
V4_FLIPS = "The central reading crosses 1.00x across these lives: the economic life matters to the answer."
V4_STABLE = "The central reading does not cross 1.00x across these lives. Other parameters are as set in the controls."
REGISTER_TITLE = "Every input and where it comes from"
REGISTER_SUB = ("One row per figure the model uses (a fiscal year of an entity, or an item of it). Allocated figures show their low, "
                "middle and high share values.")
REGISTER_FOOT = ("Sources are the filings named in capex_model_facts.csv. A method note is a working note of the model, not a public "
                 "source; a figure resting on one is marked.")
GAPS_TITLE = "Looked for and not found"
NOTES_TITLE = "Notes by company"

# ---------------------------------------------------------------- cross links
RELATED_TITLE = "Related"
R4_LINE = ("How this differs from the R4 signal, Hyperscaler AI ROI proxy: R4 is a payback proxy (capex divided by cloud revenue). "
           "This page is a return-on-capital test: whether the cash the cloud businesses earn covers the return the capital in service "
           "requires, with leases and tax allowed for.")
CAPEX_LINE = "Capex and guidance as filed, by company."
INPUTS_CHECK_LINE = "Each base-case input of this model, re-tested every week against the newest filings, guidance and news."
T7_LINE = ("Leases signed but not yet commenced, and the claims around them (T7); the committed-rent band here draws on the same lease "
           "notes.")
NO_DATA = ("The model inputs are not in this data root (data/processed/capex_model_inputs.json), so the model cannot be run. "
           "Nothing is shown in their place.")
