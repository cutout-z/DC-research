"""Where the data plane lives: one setting, read once, at import.

The data and the analysis code stay in the Streamlit repo (`ai-research`); this app only reads
them. `AIDC_DATA_ROOT` names that checkout. Unset (or empty) it is the Mac's live, pull-only
checkout `~/ai-research` (on `main`, fast-forwarded by the autopull job; never a working clone).
Any other machine, or a run against another copy, sets the one variable:

    AIDC_DATA_ROOT=/srv/ai-research bash run.sh
    AIDC_DATA_ROOT=/srv/ai-research python3 -m pytest tests -q

It is read at import and the paths below are plain `Path` constants, so set it before the
process starts (a test that changes it must import in a fresh interpreter). The perturbed-copy
sweep (scripts/perturb_data.py, tests/conftest.py) points the same variable at its copy.

Nothing here touches the filesystem: a path that does not exist is the caller's honest empty
state (`headers.streamlit_nav()` returns [], a loader raises), not an import-time failure.
"""
from __future__ import annotations

import os
from pathlib import Path

ENV_VAR = "AIDC_DATA_ROOT"
DEFAULT_DATA_ROOT = Path("/Users/zalen/ai-research")

# `absolute()`, not `resolve()`: a symlinked checkout keeps the path it was given.
DATA_ROOT = Path(os.environ.get(ENV_VAR) or DEFAULT_DATA_ROOT).expanduser().absolute()

DATA_DIR = DATA_ROOT / "data"
APP_ROOT = DATA_ROOT / "app"
HOME_PY = APP_ROOT / "Home.py"

# Written by scripts/perturb_data.py into its copy. "Where the data is" and "this copy has had its
# numbers moved" are different facts; only the second one makes the suite skip `data_integrity`.
PERTURBED_MARKER = DATA_ROOT / ".aidc-perturbed"

# The Brain dashboard's notes mirror: the clipped public-source notes behind the radar's articles,
# opted in note by note and sanitised by its exporter (ai-wif-brain-dashboard bin/export-public-notes.py,
# Fable audit F10). Optional and outside the data root: absent, "Read note" shows the projection's snippet.
# AIDC_NOTES_PATH names another file; set it empty to turn full notes off (the tests do, by default).
NOTES_ENV_VAR = "AIDC_NOTES_PATH"
DEFAULT_NOTES_PATH = Path.home() / "ai-wif-brain-dashboard" / "data" / "notes" / "public_notes.json"
_notes_env = os.environ.get(NOTES_ENV_VAR)
NOTES_PATH: Path | None = (None if _notes_env == ""
                           else Path(_notes_env or DEFAULT_NOTES_PATH).expanduser().absolute())
