"""The capex return model's controlled region, rendered without the web app, so the static site can run it in the
reader's browser.

The page's controls are sliders (any hurdle, life, lag or tax in range), so the static export cannot pre-render
their states. Instead the published site carries this package's source, the page's templates and the model's
inputs as one zip (BUNDLE, served at /capex-model-live.zip and written beside the pages), and
app/static/js/capex-model-live.js runs them in Pyodide: the same compute, the same view model and the same
template as the /partials/capex-return-model route. The route renders through render() too, so there is one code
path, not a port (tests/test_capex_model_live.py checks the browser's environment gives the same bytes).

Nothing here may import plotly, pandas or the rest of the app: the bundle is exactly the files listed below, and
app/views/__init__.py is replaced in it by an empty module (the real one imports every page).
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

APP = Path(__file__).resolve().parents[1]

# The app modules a render imports, relative to the repo root. tests/test_capex_model_live.py renders from a bundle
# alone, so a missing or new import fails there, not in a reader's browser.
MODULES = (
    "app/__init__.py", "app/config.py", "app/chart_tokens.py", "app/datatable.py", "app/markup.py",
    "app/data_capex_model.py", "app/figures_capex_model.py",
    "app/capex_model/__init__.py", "app/capex_model/engine.py", "app/capex_model/compute.py", "app/capex_model/live.py",
    "app/content/__init__.py", "app/content/capex_return_model.py",
    "app/views/capex_model.py",
)
STUBS = {"app/views/__init__.py": '"""Bundle stub: the app\'s app/views/__init__.py imports every page."""\n'}
TEMPLATES = ("partials/crm_results.html", "partials/_crm_macros.html", "partials/_macros.html")
# The model's inputs and the filed rows their `src` keys name (app/data_capex_model.py), relative to the data
# directory (config.DATA_DIR).
DATA = ("processed/capex_model_inputs.json", "reference/capex_model_facts.csv")
TEMPLATE = "partials/crm_results.html"


def environment(templates_dir: Path | None = None):
    """A Jinja environment with what the region's templates use from the app's own (app/main.py): HTML
    autoescaping, as Starlette sets it, and the md filters."""
    from jinja2 import Environment, FileSystemLoader

    from app.markup import md, md_untrusted
    env = Environment(loader=FileSystemLoader(str(templates_dir or APP / "templates")), autoescape=True)
    env.filters["md"] = md
    env.filters["md_untrusted"] = md_untrusted
    return env


def render(qp, env=None) -> str:
    """The region for one set of control values (a query-string mapping), as /partials/capex-return-model returns it."""
    from app import views  # noqa: F401  (in the bundle: the stub; in the app: every page, already imported)
    from app.content import capex_return_model as crc
    from app.views import capex_model as V
    return (env or environment()).get_template(TEMPLATE).render(results=V.crm_results(V.crm_filter(qp)), c=crc)


def bundle() -> bytes:
    """The zip the browser unpacks: MODULES, the views stub, TEMPLATES under templates/ and DATA under data/.
    Deterministic (sorted, fixed timestamps), so the same build gives the same file."""
    from app.config import DATA_DIR
    repo = APP.parent
    files = {m: (repo / m).read_bytes() for m in MODULES}
    files.update({k: v.encode() for k, v in STUBS.items()})
    files.update({f"templates/{t}": (APP / "templates" / t).read_bytes() for t in TEMPLATES})
    files.update({f"data/{d}": (DATA_DIR / d).read_bytes() for d in DATA})
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, files[name])
    return buf.getvalue()
