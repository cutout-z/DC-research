"""The AI capex return model, composed from the inputs JSON and the reference engine.

A faithful Python port of the page logic in the private model repo's `analysis/build_dashboard_v2.py` (its `adapter-js`
block, `Adapter`): inputs JSON -> model objects, the three scenario sets, the headline coverage (latest fiscal year and
last twelve months), the forecast, the lease memo, the breakeven, the circular-funding stress and the indirect line.
Two pins, deliberately separate: the engine (engine.py) is `model_v2.py` @ 6079fd3 (unchanged since); the Adapter, LTM
logic included, is ported from build_dashboard_v2.py at private commit 48d20eb.
The maths is the engine's; nothing here changes it. tests/fixtures/capex_model_golden.json is generated from that
page's own JavaScript. Rendering lives elsewhere (app/views/capex_model.py).

Units: USD millions as filed. Times are fractional years on each entity's own fiscal calendar.

A scenario set is chosen per entity by computed coverage, never assumed: for every entity the latest
fiscal year's coverage is evaluated with the low, middle and high allocation share applied to ALL of its
allocated fields (capex, contribution add-back, rent, operating-lease additions, opening stock, stub,
leases not yet commenced, guidance). Favourable = the share with the highest coverage, adverse = the
lowest, central = the middle one.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field, replace
from functools import lru_cache
from typing import Any, Optional

from app.capex_model import engine as M

BONUS_AFTER = 2025 + 18 / 365      # 19 Jan 2025: bonus depreciation applies to vintages after this date
HORIZON = 2030                     # last fiscal year shown in the forecast
DEFAULT_TERM = 10                  # lease term when none is disclosed (labelled assumption)
SCN = ("favourable", "central", "adverse")
KEYS = ("low", "mid", "high")
LIFE_PRESETS = (4, 5, 6)


# --------------------------------------------------------------------------- parameters

@dataclass(frozen=True)
class Params:
    hurdle: float = 0.15
    life_it: float = 5
    life_fac: float = 20
    lag_it: float = 0.5
    lag_fac: float = 1.5
    tax: float = 0.15
    bonus: bool = True
    scenario: str = "central"
    lease_mode: str = "rent"       # 'rent' (filed treatment) | 'capex' (memo: operating leases as capex)
    lease_pick: str = "mid"        # 'mid' | 'max' of the disclosed lease-term range

    @property
    def toggle(self) -> bool:
        return self.lease_mode == "capex"


def default_params(data: dict) -> Params:
    d = (data or {}).get("params_default") or {}
    return Params(
        hurdle=d.get("hurdle", 0.15), life_it=d.get("life_it", 5), life_fac=d.get("life_fac", 20),
        lag_it=d.get("lag_it", 0.5), lag_fac=d.get("lag_fac", 1.5), tax=d.get("tax", 0.15),
        bonus=bool(d["bonus"]) if "bonus" in d else True, scenario=d.get("scenario") or "central")


# --------------------------------------------------------------------------- small helpers

def fy_year(fy) -> Optional[int]:
    m = re.search(r"(\d{4})", str(fy))
    return int(m.group(1)) if m else None


def _nn(x) -> bool:
    return x is not None


def has_val(o) -> bool:
    return bool(o) and (_nn(o.get("value")) or _nn(o.get("low")) or _nn(o.get("mid")) or _nn(o.get("high")))


@dataclass
class Rng:
    low: float
    mid: float
    high: float
    gap: bool = False
    incomplete: bool = False

    def __getitem__(self, key: str) -> float:
        return getattr(self, key)


def range_of(o) -> Rng:
    """{low, mid, high} or {value} -> Rng. A gap (no value at all) is zeros with gap=True: callers flag it, never
    present it as data. Where some ends are null, the missing ends take the nearest available end (incomplete)."""
    if not has_val(o):
        return Rng(0, 0, 0, gap=True)
    lo, mid, hi, v = o.get("low"), o.get("mid"), o.get("high"), o.get("value")
    if not _nn(lo) and not _nn(mid) and not _nn(hi):
        return Rng(v, v, v)
    inc = not (_nn(lo) and _nn(mid) and _nn(hi))
    if not _nn(lo):
        lo = mid if _nn(mid) else hi
    if not _nn(hi):
        hi = mid if _nn(mid) else lo
    if not _nn(mid):
        mid = (lo + hi) / 2
    return Rng(lo, mid, hi, incomplete=inc)


@dataclass
class Term:
    years: float
    lo: float
    hi: float
    basis: str


def lease_term(ent: dict, P: Params) -> Term:
    l = (ent.get("forecast") or {}).get("lnc")
    lt = ent.get("lease_term")
    if lt and _nn(lt.get("min")) and _nn(lt.get("max")):
        lo, hi, basis = lt["min"], lt["max"], "disclosed lease term"
    elif l and _nn(l.get("term_min")) and _nn(l.get("term_max")):
        lo, hi, basis = l["term_min"], l["term_max"], "disclosed range for leases not yet commenced"
    elif l and _nn(l.get("term_avg")):
        lo = hi = l["term_avg"]
        basis = "disclosed average term (no range filed)"
    elif l and _nn(l.get("term_max")):
        lo = hi = l["term_max"]
        basis = "disclosed maximum term (no range or average filed)"
    else:
        lo = hi = DEFAULT_TERM
        basis = "assumption: no lease term disclosed"
    years = lo if P.lease_pick == "min" else (hi if P.lease_pick == "max" else (lo + hi) / 2)
    return Term(years, lo, hi, basis)


def econ_for(ent: dict, P: Params) -> M.Econ:
    return M.Econ(s_it=ent["s_it"]["value"], n_it=P.life_it, n_fac=P.life_fac, L_it=P.lag_it, L_fac=P.lag_fac,
                  tax=0 if ent.get("tax_zero") else P.tax, sched_it="macrs5", sched_fac="sl",
                  bonus_after=BONUS_AFTER if P.bonus else None)


def opening_amount(o, key: str) -> float:
    """Opening stock at the scenario key: {low, mid, high} if given, else net_ppe."""
    if not o:
        return 0
    r = {"low": o.get("low"), "mid": o.get("mid"), "high": o.get("high")}
    if has_val(r):
        return range_of(r)[key]
    return o["net_ppe"] if _nn(o.get("net_ppe")) else 0


def opening_vintages(ent: dict, econ: M.Econ, key: str) -> list:
    """Net PP&E before the first year in scope, split by the IT share, each part annuitised over half the bucket
    life (assumption: remaining life of earlier assets) from that date, no build lag."""
    o = ent.get("opening")
    amt = opening_amount(o, key)
    if not o or not (amt > 0):
        return []
    return [
        M.Vintage(amt * econ.s_it, o["at"], o["at"], opening=True, lease_term=econ.n_it / 2),
        M.Vintage(amt * (1 - econ.s_it), o["at"], o["at"], opening=True, lease_term=econ.n_fac / 2),
    ]


def lnc_total(lnc: dict, key: str) -> float:
    if lnc.get("scaled") and has_val(lnc["scaled"]):
        return range_of(lnc["scaled"])[key]
    return lnc["total"]


# --------------------------------------------------------------------------- one entity at one allocation key

@dataclass
class Row:
    """One fiscal year of one entity, at the allocation key in force."""
    fy: str
    year: Optional[int]
    start: float
    end: float
    capex: float
    y: dict
    flow: Optional[M.Flow] = None
    capex_gap: bool = False
    capex_partial: bool = False
    con_incomplete: bool = False
    rent_gap: bool = False
    rev_memo: float = 0
    contribution: Optional[float] = None
    op_lease: float = 0
    op_gap: bool = False


@dataclass
class Built:
    name: str
    role: str
    ent: dict
    key: str
    term: Term
    econ: Optional[M.Econ] = None
    rows: list = field(default_factory=list)
    lease_vintages: list = field(default_factory=list)
    ltm_flow: Optional[M.Flow] = None
    stub: Optional[dict] = None
    stub_vintage: Optional[M.Vintage] = None
    lnc: Optional[dict] = None
    entity: Optional[M.Entity] = None
    entity_hist: Optional[M.Entity] = None
    vintages_hist: list = field(default_factory=list)
    memo_excluded: bool = False
    margin_own_filed: bool = True
    ltm_why: Optional[str] = None            # why no LTM flow could be built (a gap): never a number from a filled gap
    ltm_rent_gap: bool = False
    ltm_rent_why: Optional[str] = None
    ltm_window: Optional[dict] = None

    @property
    def last(self) -> Optional[Row]:
        return self.rows[-1] if self.rows else None


def build_entity(ent: dict, P: Params, key: str) -> Built:
    term = lease_term(ent, P)
    lnc_raw = (ent.get("forecast") or {}).get("lnc")
    b = Built(name=ent["name"], role=ent["role"], ent=ent, key=key, term=term,
              lnc=lnc_raw if (lnc_raw and _nn(lnc_raw.get("total"))) else None)
    if not ent.get("s_it") or not _nn(ent["s_it"].get("value")):
        return b                      # memo entities (no IT share): listed, never calculated
    econ = econ_for(ent, P)
    b.econ = econ
    hist = opening_vintages(ent, econ, key)
    any_in_layer = False
    for y in ent.get("years") or []:
        cap = range_of(y.get("capex"))
        con = range_of(y["contribution"]) if has_val(y.get("contribution")) else None
        hist.append(M.Vintage(cap[key], y["start"], y["end"]))
        row = Row(fy=y["fy"], year=fy_year(y["fy"]), start=y["start"], end=y["end"], capex=cap[key], y=y,
                  capex_gap=cap.gap, capex_partial=bool(y.get("capex") and y["capex"].get("partial")),
                  con_incomplete=bool(con and con.incomplete))
        rev_o = y.get("revenue")
        if con and rev_o and _nn(rev_o.get("value")):
            rev = rev_o["value"]
            rr = range_of(y.get("rent"))
            row.rent_gap = rr.gap
            rent = 0 if rr.gap else rr[key]
            il = y.get("in_layer_rent_deducted")
            inl = il["value"] if (il and _nn(il.get("value"))) else 0
            lm = y.get("in_layer_revenue_memo")
            row.rev_memo = lm["value"] if (lm and _nn(lm.get("value"))) else inl
            if inl > 0:
                any_in_layer = True
            row.contribution = con[key]
            row.flow = M.Flow(start=y["start"], end=y["end"], revenue=rev, m_pre=(con[key] + rent) / rev if rev > 0 else 0,
                              rent=rent, in_layer_rent=inl)
        op = range_of(y.get("op_lease_rou_excluded"))
        row.op_lease = 0 if op.gap else op[key]
        row.op_gap = op.gap
        if row.op_lease > 0:
            b.lease_vintages.append(M.Vintage(row.op_lease, y["start"], y["end"], lease_term=term.years))
        b.rows.append(row)
    vint = list(hist)
    st = ent.get("stub")
    if st and has_val(st.get("capex")):
        sc = range_of(st["capex"])[key]
        b.stub_vintage = M.Vintage(sc, st["start"], st["end"], stub=True)
        vint.append(b.stub_vintage)
        b.stub = {"label": st.get("label"), "start": st["start"], "end": st["end"], "capex": sc}
        sop = range_of(st.get("op_lease_rou_excluded"))
        if not sop.gap and sop[key] > 0:
            b.lease_vintages.append(M.Vintage(sop[key], st["start"], st["end"], stub=True, lease_term=term.years))
    last = b.last
    # The lease memo uses allocated operating-lease additions and allocated rent only. An entity whose rent is a
    # gap has no allocated rent to remove, so it gets no lease vintages either (left out of the memo; page says so).
    if last and last.flow and last.rent_gap:
        b.lease_vintages = []
        b.memo_excluded = True
    lt = ent.get("ltm")
    # Last twelve months = latest FY + current YTD - prior-year YTD, built in the inputs from the filed rows. The requirement is
    # the same engine function over the LTM window, so only the flow and the window differ. A flow that could not be built (a gap)
    # leaves ltm_flow None and the reason in ltm_why.
    if lt and last and last.flow:
        w = lt.get("window") or {}
        b.ltm_window = {"label": lt.get("label") or "LTM", "start": lt.get("start"), "end": lt.get("end"), "from": w.get("from"), "to": w.get("to")}
        lrev_o, lcon_o = lt.get("revenue"), lt.get("contribution")
        if not (lrev_o and _nn(lrev_o.get("value"))):
            b.ltm_why = (lrev_o or {}).get("note") or "last-twelve-months revenue is a gap in the inputs"
        elif not has_val(lcon_o):
            b.ltm_why = (lcon_o or {}).get("note") or "last-twelve-months contribution is a gap in the inputs"
        elif not (_nn(lt.get("start")) and _nn(lt.get("end"))):
            b.ltm_why = "no last-twelve-months window in the inputs"
        else:
            lcon, lrev, rent_gap = range_of(lcon_o)[key], lrev_o["value"], False
            if "rent" not in lt:
                lrent = last.flow.rent                       # inputs without an LTM rent line: the latest fiscal year's rent
            elif has_val(lt["rent"]):
                lrent = range_of(lt["rent"])[key]
            elif last.rent_gap:
                lrent = 0                                    # rent is not disclosed for this entity in any period
            else:
                lrent, rent_gap = 0, True                    # rent is filed for the year but a gap in the window
            lil = lt.get("in_layer_rent_deducted")
            linl = lil["value"] if (lil and _nn(lil.get("value"))) else last.flow.in_layer_rent
            b.ltm_rent_gap = rent_gap
            b.ltm_rent_why = ((lt.get("rent") or {}).get("note") or "operating rent for the window is a gap in the inputs") if rent_gap else None
            b.ltm_flow = M.Flow(start=lt["start"], end=lt["end"], revenue=lrev, m_pre=(lcon + lrent) / lrev if lrev > 0 else 0,
                                rent=lrent, in_layer_rent=linl)
    elif not lt:
        b.ltm_why = "no last-twelve-months block in the inputs"
    b.vintages_hist = hist
    b.margin_own_filed = not any_in_layer
    b.entity = M.Entity(name=ent["name"], econ=econ, vintages=vint, margin_own_filed=b.margin_own_filed)
    b.entity_hist = M.Entity(name=ent["name"], econ=econ, vintages=hist, margin_own_filed=b.margin_own_filed)
    return b


def is_cloud(b: Built) -> bool:
    return b.role == "cloud" and bool(b.rows) and b.last.flow is not None


# --------------------------------------------------------------------------- scenario sets

def select_keys(data: dict, P: Params) -> dict:
    """Which allocation key each entity uses in each scenario set (see the module docstring)."""
    keys = {"favourable": {}, "central": {}, "adverse": {}, "cov": {}}
    for e in data["entities"]:
        cov, any_ = {}, False
        for k in KEYS:
            b = build_entity(e, P, k)
            if not is_cloud(b):
                cov[k] = None
                continue
            cov[k] = M.cov1([b.entity], {b.name: b.last.flow}, P.hurdle, True, True)["cov1"]
            if cov[k] is not None:
                any_ = True
        fav = adv = "mid"
        if any_:
            vals = [v for v in cov.values() if v is not None]
            hi, lo = max(vals), min(vals)
            if hi - lo > 1e-9:
                fi = ai = False
                for k in KEYS:
                    if cov[k] is None:
                        continue
                    if not fi and cov[k] >= hi - 1e-12:
                        fav, fi = k, True
                    if not ai and cov[k] <= lo + 1e-12:
                        adv, ai = k, True
        keys["favourable"][e["name"]] = fav
        keys["central"][e["name"]] = "mid"
        keys["adverse"][e["name"]] = adv
        keys["cov"][e["name"]] = cov
    return keys


# --------------------------------------------------------------------------- forecast

def _match_guided(guided: list, used: set, y_start: float, y_end: float, year_label: int):
    """A guided row is used for the forecast fiscal year it overlaps most (at least 45% of the year); each row once.
    Guidance rows carry their own span on the same absolute axis (CY2026 = 2026.0-2027.0)."""
    best, best_ov = -1, 0.0
    for q, g in enumerate(guided):
        if q in used or not has_val(g):
            continue
        if _nn(g.get("start")) and _nn(g.get("end")):
            ov = max(0.0, min(y_end, g["end"]) - max(y_start, g["start"])) / (y_end - y_start)
        else:
            ov = 1.0 if fy_year(g.get("fy")) == year_label else 0.0
        if ov >= 0.45 and ov > best_ov + 1e-9:
            best, best_ov = q, ov
    if best < 0:
        return None
    used.add(best)
    return guided[best], best_ov


@dataclass
class ForecastEntity:
    name: str
    key: str
    latest_fy: str
    latest_year: int
    rev_last: float
    capex: list           # full-year capex per forecast year
    vintage_capex: list   # the vintage amount added each year (year 1 net of the stub)
    basis: list
    stub_amt: float
    added: list           # committed rent from leases not yet commenced, per year (mid-year convention)
    lnc: Optional[dict]
    lnc_used: float
    lnc_ok: bool
    term: Term


@dataclass
class Forecast:
    fc: dict              # {years: [...], first_k, first_label}
    n: int
    labels: list
    per: list
    inputs: list
    horizon: int


def forecast_h1_ext(inputs: list, r: float, labels: list) -> dict:
    """engine.forecast_h1 plus three fields the page needs per year: `rent` (total rent charged),
    `added_rent` (of which committed rent from leases not yet commenced) and `rev_pre` (sum of revenue x m_pre).
    The engine's own numbers are used for everything it returns; the extras only re-add inputs."""
    out = M.forecast_h1(inputs, r, True, labels)
    for y in out["years"]:
        k = y["k"]
        rent = added = revm = 0.0
        for fi in inputs:
            rv = M.forecast_revenue(fi.rev_last, fi.g, fi.delta, k)
            add = 0.0 if (k == 0 or not fi.added_rent) else fi.added_rent[min(k, len(fi.added_rent)) - 1]
            rt = fi.rent_last + add
            if not fi.entity.margin_own_filed:
                rt += fi.in_layer_rent
            rent += rt
            added += add
            revm += rv * fi.m_pre
        y["rent"], y["added_rent"], y["rev_pre"] = rent, added, revm
    return out


def compute_forecast(built: list, P: Params) -> Optional[Forecast]:
    clouds = [b for b in built if is_cloud(b)]
    if not clouds:
        return None
    min_latest = min(b.last.year for b in clouds)
    n = HORIZON - min_latest
    if n < 1:
        return None
    inputs, per = [], []
    for b in clouds:
        key = b.key
        lr = b.last
        f = lr.flow
        guided = (b.ent.get("forecast") or {}).get("capex_guided") or []
        lnc = b.lnc
        lnc_used = lnc_total(lnc, key) if lnc else 0
        lnc_ok = bool(lnc and lnc_total(lnc, key) > 0 and _nn(lnc.get("from")) and _nn(lnc.get("to")))
        # The H1 stub is in the history at its actual amount. Year 1 is a full-year figure (guided or flat, at least the
        # stub actual); the remainder (year-1 total minus stub) is the year-1 vintage over [stub end, year-1 end).
        stub_ok = bool(b.stub and b.stub["start"] >= lr.end - 1e-3 and b.stub["end"] <= lr.end + 1 + 1e-3)
        stub_amt = b.stub["capex"] if stub_ok else 0
        prev, prev_kind = lr.capex, "last filed year"
        totals, vint, basis, added, used = [], [], [], [], set()
        for j in range(1, n + 1):
            yr = lr.year + j
            mg = _match_guided(guided, used, lr.end + j - 1, lr.end + j, yr)
            if mg:
                g, overlap = mg
                prev, prev_kind = range_of(g)[key], "guided"
                bs = {"fy": f"FY{yr}", "kind": "guided", "src": g.get("src"), "from": g.get("fy"), "overlap": overlap,
                      "assumed": overlap < 0.999, "statement": g.get("company_statement") or None,
                      "note": g.get("guidance_notes") or None}
            else:
                bs = {"fy": f"FY{yr}", "kind": f"assumption: flat at last {prev_kind} level", "src": None}
            if j == 1 and stub_amt > 0:
                bs["stub"] = {"label": b.stub["label"], "amount": stub_amt, "planned": prev}
                stub_len = b.stub["end"] - b.stub["start"]
                run_rate = stub_amt / stub_len if (not mg and stub_len > 0) else stub_amt
                if run_rate > prev + 1e-9:
                    prev = run_rate
                    prev_kind = "stub-actual" if mg else "latest run-rate"
                    bs["kind"] = ("stub actual above guidance" if mg else
                                  f"no guidance: flat at the latest run-rate ({b.stub['label']} actual, annualised), above the last filed year")
                bs["remainder"] = prev - stub_amt
            bs["total"] = prev
            basis.append(bs)
            totals.append(prev)
            vint.append(prev - stub_amt if (j == 1 and stub_amt > 0) else prev)
            if lnc_ok:
                added.append(M.committed_rent_midyear(lnc_used, b.term.years, lnc["from"], lnc["to"], f.end + j - 1, f.end + j))
        hist = (M.Entity(name=b.name, econ=b.econ, vintages=b.vintages_hist + [b.stub_vintage], margin_own_filed=b.margin_own_filed)
                if stub_amt > 0 else b.entity_hist)
        inputs.append(M.ForecastInput(entity=hist, rev_last=f.revenue, m_pre=f.m_pre, rent_last=f.rent, first_start=lr.end,
                                      capex=vint, g=0, delta=0, added_rent=added, in_layer_rent=f.in_layer_rent,
                                      year1_start=b.stub["end"] if stub_amt > 0 else None))
        per.append(ForecastEntity(name=b.name, key=key, latest_fy=lr.fy, latest_year=lr.year, rev_last=f.revenue, capex=totals,
                                  vintage_capex=vint, basis=basis, stub_amt=stub_amt, added=added, lnc=lnc, lnc_used=lnc_used,
                                  lnc_ok=lnc_ok, term=b.term))
    labels = []
    for k in range(1, n + 1):
        labels.append(" / ".join(sorted({f"FY{b.last.year + k}" for b in clouds})))
    return Forecast(fc=forecast_h1_ext(inputs, P.hurdle, labels), n=n, labels=labels, per=per, inputs=inputs, horizon=HORIZON)


# --------------------------------------------------------------------------- one scenario set

@dataclass
class Scenario:
    scn: str
    keys: dict
    key_cov: dict
    built: list
    cloud: list
    entities: list
    latest_flows: dict
    toggle: bool
    include_rent: bool
    hurdle: float = 0.15
    ltm_flows: dict = field(default_factory=dict)
    latest: dict = field(default_factory=dict)
    ltm: Optional[dict] = None
    ltm_per: dict = field(default_factory=dict)   # per company: coverage on its own LTM window, or why it is n/a
    ltm_why: dict = field(default_factory=dict)
    totals: dict = field(default_factory=dict)
    totals_ltm: Optional[dict] = None
    # full (not lite) only
    series_cutoff: Optional[int] = None
    opening_cutoff: Optional[int] = None
    series_left_out: list = field(default_factory=list)
    series: list = field(default_factory=list)
    breakeven: Optional[float] = None
    breakeven_ltm: Optional[float] = None
    breakeven_side: Optional[str] = None
    base: Optional[dict] = None
    memo: Optional[dict] = None
    base_breakeven: Optional[float] = None
    memo_breakeven: Optional[float] = None
    forecast: Optional[Forecast] = None
    indirect: list = field(default_factory=list)


def compute_scenario(data: dict, P: Params, scn: str, lite: bool = False, keys: Optional[dict] = None) -> Scenario:
    keys = keys or select_keys(data, P)
    built = [build_entity(e, P, keys[scn][e["name"]]) for e in data["entities"]]
    cloud = [b for b in built if is_cloud(b)]
    entities = [b.entity for b in cloud]
    toggle = P.toggle
    include_rent = not toggle
    lease_v = {b.name: b.lease_vintages for b in cloud}
    latest_flows = {b.name: b.last.flow for b in cloud}
    ltm_flows, ltm_why = {}, {}
    for b in cloud:
        if b.ltm_flow and not (toggle and b.ltm_rent_gap):
            ltm_flows[b.name] = b.ltm_flow
        else:
            ltm_why[b.name] = (("operating rent for the window is a gap, so the lease-as-capex view cannot be built for it: " + str(b.ltm_rent_why))
                               if b.ltm_flow else (b.ltm_why or "no last-twelve-months figures in the inputs"))

    def cov(flows, tg, rent_on):
        if tg:
            return M.cov1_lease_toggle(entities, flows, P.hurdle, lease_v, True, False)
        return M.cov1(entities, flows, P.hurdle, True, rent_on)

    S = Scenario(scn=scn, keys=keys[scn], key_cov=keys["cov"], built=built, cloud=cloud, entities=entities,
                 latest_flows=latest_flows, toggle=toggle, include_rent=include_rent, hurdle=P.hurdle)
    # Per company: coverage on its own LTM window. The system total is all or nothing: a partial LTM would mix bases, so one
    # company with a gap leaves it n/a (its reason is listed).
    ltm_avail = cov(ltm_flows, toggle, include_rent) if ltm_flows else None
    for b in cloud:
        per = ltm_avail["per_entity"].get(b.name) if ltm_avail else None
        w = b.ltm_window or {}
        if per:
            S.ltm_per[b.name] = {"C": per["C"], "req": per["req"], "cov": per["C"] / per["req"] if per["req"] > 0 else None,
                                 "revenue": ltm_flows[b.name].revenue, "label": w.get("label"), "start": w.get("start"), "end": w.get("end"),
                                 "from": w.get("from"), "to": w.get("to"), "why": None}
        else:
            S.ltm_per[b.name] = {"C": None, "req": None, "cov": None, "revenue": None, "label": w.get("label"), "start": w.get("start"),
                                 "end": w.get("end"), "from": w.get("from"), "to": w.get("to"),
                                 "why": ltm_why.get(b.name) or "no last-twelve-months figures in the inputs"}
    S.ltm_why = ltm_why
    ltm_ok = len(ltm_flows) == len(cloud) and len(cloud) > 0
    if not ltm_ok:
        ltm_flows = {}
    S.ltm_flows = ltm_flows
    S.latest = cov(latest_flows, toggle, include_rent)
    S.ltm = ltm_avail if ltm_ok else None
    gross = memo_rev = ded = 0.0
    for b in cloud:
        r = b.last
        gross += r.flow.revenue
        memo_rev += r.rev_memo
        ded += r.flow.in_layer_rent
    S.totals = {"gross": gross, "net": gross - memo_rev, "revenue_memo": memo_rev, "in_layer_rent": ded}
    S.totals_ltm = M.revenue_totals(entities, ltm_flows) if S.ltm else None
    if lite:
        return S
    years, cutoff = {}, math.inf
    for b in cloud:
        cutoff = min(cutoff, b.last.year)
        for r in b.rows:
            if r.flow:
                years[r.year] = True
    S.series_cutoff = cutoff
    open_end = -math.inf
    for b in cloud:
        if opening_amount(b.ent.get("opening"), b.key) > 0:
            open_end = max(open_end, b.ent["opening"]["at"] + P.life_it / 2)
    S.opening_cutoff = math.floor(open_end - 1 + 1e-9) if math.isfinite(open_end) else None
    S.series_left_out = sorted(y for y in years if y > cutoff)
    for y in sorted(y for y in years if y <= cutoff):
        fl, n = {}, 0
        for b in cloud:
            for r in b.rows:
                if r.flow and r.year == y:
                    fl[b.name] = r.flow
                    n += 1
        res = cov(fl, toggle, include_rent)
        S.series.append({"year": y, "cov": res["cov1"], "C": res["C"], "req": res["req"], "n": n})
    extra = lease_v if toggle else None
    S.breakeven = M.breakeven_h1(entities, latest_flows, True, include_rent, extra)
    S.breakeven_ltm = M.breakeven_h1(entities, ltm_flows, True, include_rent, extra) if ltm_ok else None
    if S.breakeven is None and entities:
        S.breakeven_side = "above" if M.cov1(entities, latest_flows, 1.0, True, include_rent, extra)["cov1"] >= 1 else "below"
    # lease treatments side by side, independent of the mode in force
    S.base = M.cov1(entities, latest_flows, P.hurdle, True, True)
    S.memo = M.cov1_lease_toggle(entities, latest_flows, P.hurdle, lease_v, True, False)
    S.base_breakeven = M.breakeven_h1(entities, latest_flows, True, True, None)
    S.memo_breakeven = M.breakeven_h1(entities, latest_flows, True, False, lease_v)
    S.forecast = compute_forecast(built, P)
    # indirect line: requirement only
    for b in built:
        if b.role == "indirect" and b.entity:
            rows = [{"fy": r.fy, "year": r.year, "capex": r.capex,
                     "req": M.requirement(b.entity.vintages, b.econ, P.hurdle, r.start, r.end, True)} for r in b.rows]
            lt, st, win = b.ent.get("ltm"), b.ent.get("stub"), None
            if lt and _nn(lt.get("start")) and _nn(lt.get("end")):
                win = {"label": lt.get("label") or "LTM", "start": lt["start"], "end": lt["end"]}
            elif st and _nn(st.get("end")):
                win = {"label": f"LTM to end of {st.get('label')}", "start": st["end"] - 1, "end": st["end"]}
            S.indirect.append({"name": b.name, "rows": rows, "entity": b,
                               "ltm": {"label": win["label"], "req": M.requirement(b.entity.vintages, b.econ, P.hurdle, win["start"], win["end"], True)} if win else None})
    return S


# --------------------------------------------------------------------------- circular funding (memo)

def _entity_of(data: dict, circ: dict) -> Optional[str]:
    want = str(circ.get("entity") or circ.get("funder") or "").lower()
    want = {"amazon": "aws", "alphabet": "google cloud"}.get(want, want)
    hit = None
    for e in data["entities"]:
        if e["name"].lower() == want:
            hit = e["name"]
    return hit


def compute_circular(data: dict, S: Scenario, P: Params) -> dict:
    """Per each entry's `netting`: same_period removes the revenue the cloud books from that lab in its latest fiscal
    year at the cloud's pre-rent margin (like for like); not_netted entries are listed with their date, never subtracted
    (the funding post-dates the flow period)."""
    rows, removed, by_entity = [], 0.0, {}
    for c in data.get("circular") or []:
        name = _entity_of(data, c)
        mode = c.get("netting") or "not_netted"
        row = {"c": c, "entity": name, "mode": mode, "gap": not _nn(c.get("funded_cum")) and not _nn(c.get("revenue_from")),
               "removed": None, "m": None, "applied": False}
        f = S.latest_flows.get(name) if name else None
        if mode == "same_period" and f and _nn(c.get("revenue_from")):
            row["m"] = f.m_pre
            row["removed"] = c["revenue_from"] * f.m_pre
            row["applied"] = True
            removed += row["removed"]
            by_entity[name] = by_entity.get(name, 0.0) + row["removed"]
        rows.append(row)
    C, R = S.latest["C"], S.latest["req"]
    ents = []
    for n, rem in by_entity.items():
        per = S.latest["per_entity"][n]
        ents.append({"name": n, "removed": rem, "cov_with": per["C"] / per["req"] if per["req"] > 0 else None,
                     "cov_without": (per["C"] - rem) / per["req"] if per["req"] > 0 else None})
    return {"rows": rows, "removed": removed, "entities": ents,
            "cov_with": C / R if R > 0 else None, "cov_without": (C - removed) / R if R > 0 else None}


# --------------------------------------------------------------------------- everything for one parameter set

@dataclass
class Result:
    P: Params
    keys: dict
    scn: dict
    act: Scenario
    circ: dict
    sens: list


def compute(data: dict, P: Params) -> Result:
    keys = select_keys(data, P)
    scn = {s: compute_scenario(data, P, s, False, keys) for s in SCN}
    act = scn.get(P.scenario) or scn["central"]
    circ = compute_circular(data, act, P)
    sens = []
    for life in LIFE_PRESETS:
        P2 = replace(P, life_it=life)
        k2 = select_keys(data, P2)
        o = {"life": life, "cov": {}, "ltm": {}}
        for s in SCN:
            S = compute_scenario(data, P2, s, True, k2)
            o["cov"][s] = S.latest["cov1"]
            o["ltm"][s] = S.ltm["cov1"] if S.ltm else None
        sens.append(o)
    return Result(P=P, keys=keys, scn=scn, act=act, circ=circ, sens=sens)


# --------------------------------------------------------------------------- derived reading of a scenario

def next_year(S: Scenario) -> Optional[dict]:
    """Forecast year 1 (coverage at today's revenue with next year's capital in place), or None."""
    if not S.forecast or len(S.forecast.fc["years"]) < 2:
        return None
    return S.forecast.fc["years"][1]


def entity_next_year(S: Scenario) -> dict:
    """Coverage next year at today's revenue, per entity: the engine's forecast run on that entity alone (the system figure is
    the same calculation on all of them, so the entities' contributions and requirements add up to it)."""
    out = {}
    if not S.forecast:
        return out
    for fi, per in zip(S.forecast.inputs, S.forecast.per):
        y = M.forecast_h1([fi], S.hurdle, True)["years"][1] if fi.capex else None
        out[per.name] = None if y is None else {"cov1": y["cov1"], "lam": y["lam"], "C": y["contribution"], "req": y["req"],
                                                "revenue": y["revenue"]}
    return out


def revenue_path(S: Scenario) -> Optional[dict]:
    """Revenue needed for 1.00x in the final forecast year, against the latest year's revenue, and the compound
    yearly rate between them."""
    if not S.forecast:
        return None
    ys = S.forecast.fc["years"]
    if len(ys) < 2:
        return None
    last = ys[-1]
    i = len(ys) - 1
    need = last["revenue_needed"]
    lam = last["lam"]
    ann = (lam ** (1 / i) - 1) if (lam is not None and lam > 0) else None
    return {"label": last["label"], "needed": need, "from": ys[0]["revenue"], "per_year": ann, "total": (lam - 1) if lam is not None else None}


@lru_cache(maxsize=256)
def _cached(data_id: int, P: Params) -> Result:       # pragma: no cover - thin wrapper
    return compute(_DATA_BY_ID[data_id], P)


_DATA_BY_ID: dict = {}


def compute_cached(data: dict, P: Params) -> Result:
    """compute() memoised on (the loaded inputs object, parameters): one request renders several sections from one run."""
    _DATA_BY_ID[id(data)] = data
    return _cached(id(data), P)
