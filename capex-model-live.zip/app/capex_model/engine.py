# Source: cutout-z/DC-scenario-modelling analysis/model_v2.py @ 6079fd3 (copied verbatim below this line; do not edit here).
"""Model v2 reference calculation (MODEL_SPEC_v2.md section 5, "Calculation rules v2.1").

Pure Python 3 standard library. No file or network I/O. Data-agnostic: every input is passed in.
This module is the numerical authority that a JavaScript port is tested against to 1e-9, so:
  * all sums are plain left-to-right sums in the order of the input lists (no fsum);
  * only +, -, *, /, **, exp, log, min, max are used;
  * time is continuous, in years (floats).

Conventions
-----------
Vintage        a capex amount spent over [start, end); its cash is placed at the midpoint (t_mid), or, with
               midyear=False and for a full fiscal year (stub=False), at `start` (v1 parity tests only).
Flow           an entity's revenue / operating rent / cash margin over an interval [start, end).
Entity         vintages + economics + base-period inputs for H2.
a(...)         annual pre-tax requirement per $ of capex for one bucket (IT or facilities).
"""

from dataclasses import dataclass, field, replace
from math import exp, log
from functools import lru_cache
from typing import Callable, Dict, List, Optional, Sequence, Tuple, Union

EPS_TIME = 1e-9
MACRS5 = (0.20, 0.32, 0.192, 0.1152, 0.1152, 0.0576)
BONUS = (1.0,)

TaxSchedule = Union[str, Sequence[float]]


# --------------------------------------------------------------------------------------
# Per-dollar annual requirement
# --------------------------------------------------------------------------------------

def annuity_factor(r: float, n: float) -> float:
    """AF(r, n) = (1 - (1+r)^-n) / r ; n when r == 0."""
    if r == 0:
        return float(n)
    return (1.0 - (1.0 + r) ** (-n)) / r


def crf(r: float, n: float) -> float:
    """Capital recovery factor = 1 / AF."""
    return 1.0 / annuity_factor(r, n)


def dep_schedule(tax_schedule: TaxSchedule, n_tax: Optional[float]) -> Tuple[float, ...]:
    """Tax depreciation fractions by year after entering service.

    "sl": n_tax years of 1/n_tax (a fractional n_tax gives a final part-year of the remainder / n_tax);
    "macrs5": MACRS5; "bonus": [1.0]; or an explicit sequence of fractions.
    """
    if isinstance(tax_schedule, str):
        if tax_schedule == "macrs5":
            return MACRS5
        if tax_schedule == "bonus":
            return BONUS
        if tax_schedule == "sl":
            if n_tax is None or n_tax <= 0:
                raise ValueError("'sl' needs n_tax > 0")
            whole = int(n_tax + 1e-12)
            out = [1.0 / n_tax] * whole
            rem = n_tax - whole
            if rem > 1e-12:
                out.append(rem / n_tax)
            return tuple(out)
        raise ValueError("unknown tax schedule %r" % (tax_schedule,))
    return tuple(tax_schedule)


@lru_cache(maxsize=None)
def _a(r: float, n_econ: float, t: float, sched: Tuple[float, ...], L: float) -> float:
    af = annuity_factor(r, n_econ)
    pv = 0.0
    for k, d in enumerate(sched, start=1):
        pv += d / (1.0 + r) ** k
    pv *= t
    return (1.0 - pv) / ((1.0 - t) * af) * (1.0 + r) ** L


def a(r: float, n_econ: float, t: float, tax_schedule: TaxSchedule = "sl", L: float = 0.0,
      n_tax: Optional[float] = None) -> float:
    """Per-dollar annual requirement of one bucket.

    a = (1 - PVshield) / ((1 - t) * AF(r, n_econ)) * (1+r)^L,  PVshield = t * sum_k dep_k / (1+r)^k.
    n_tax defaults to n_econ (only used by "sl").
    """
    sched = dep_schedule(tax_schedule, n_econ if n_tax is None else n_tax)
    return _a(float(r), float(n_econ), float(t), sched, float(L))


# --------------------------------------------------------------------------------------
# Data structures
# --------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Vintage:
    amount: float
    start: float
    end: float
    stub: bool = False            # part-year at actual value (never annualised)
    opening: bool = False         # opening-stock vintage (excluded from H2 delta-K)
    lease_term: Optional[float] = None  # set for lease-toggle vintages: one facilities-like bucket over the term

    @property
    def t_mid(self) -> float:
        return (self.start + self.end) / 2.0

    @property
    def length(self) -> float:
        return self.end - self.start

    @staticmethod
    def at_mid(amount: float, t_mid: float, length: float = 1.0, **kw) -> "Vintage":
        return Vintage(amount, t_mid - length / 2.0, t_mid + length / 2.0, **kw)


@dataclass(frozen=True)
class Flow:
    """An entity's flows over [start, end): revenue, cash margin before D&A and rent (m_pre), operating rent."""
    start: float
    end: float
    revenue: float
    m_pre: float
    rent: float = 0.0
    in_layer_rent: float = 0.0    # annual rent paid to another in-layer entity (cloud-to-cloud)
    stub: bool = False

    @property
    def t_mid(self) -> float:
        return (self.start + self.end) / 2.0


@dataclass(frozen=True)
class Econ:
    """Per-entity capital economics. IT share s_it; facilities share = 1 - s_it."""
    s_it: float
    n_it: float
    n_fac: float
    L_it: float = 0.0
    L_fac: float = 0.0
    tax: float = 0.0
    sched_it: TaxSchedule = "sl"
    sched_fac: TaxSchedule = "sl"
    n_tax_it: Optional[float] = None    # default n_it
    n_tax_fac: Optional[float] = None   # default n_fac
    bonus_after: Optional[float] = None  # IT vintages with t_mid > this use "bonus" (None = switch off)


@dataclass
class Entity:
    name: str
    econ: Econ
    vintages: List[Vintage]
    margin_own_filed: bool = True
    no_base: bool = False
    m_pre_base: float = 0.0           # base period's last fiscal year cash margin (H2)
    rent_base: float = 0.0            # base period's last fiscal year operating rent (H2)
    base_start: Optional[float] = None  # per-entity override of the H2 base window
    base_end: Optional[float] = None


def vintages_from_periods(periods: Sequence[Tuple], tol: float = EPS_TIME) -> List[Vintage]:
    """Build vintages from (start, end, amount[, stub]) periods; raise ValueError if any two overlap.

    Guarantees sum(vintage amounts) == sum(period amounts): each period is exactly one vintage.
    """
    vs = []
    for p in periods:
        start, end, amount = p[0], p[1], p[2]
        stub = bool(p[3]) if len(p) > 3 else False
        if end <= start:
            raise ValueError("period end must be after start: %r" % (p,))
        vs.append(Vintage(amount, start, end, stub))
    order = sorted(range(len(vs)), key=lambda i: vs[i].start)
    for i, j in zip(order, order[1:]):
        if vs[j].start < vs[i].end - tol:
            raise ValueError("periods overlap: %r and %r" % (periods[i], periods[j]))
    return vs


# --------------------------------------------------------------------------------------
# Requirement
# --------------------------------------------------------------------------------------

def _overlap(u: float, w: float, s: float, e: float) -> float:
    return max(0.0, min(w, e) - max(u, s))


def _t_cash(v: Vintage, midyear: bool) -> float:
    if (not midyear) and (not v.stub):
        return v.start
    return v.t_mid


def _buckets(v: Vintage, econ: Econ, r: float, t_cash: float) -> List[Tuple[float, float, float, float]]:
    """[(share, a_b, in_service_start, n_b)] for a vintage."""
    if v.lease_term is not None:
        n = v.lease_term
        return [(1.0, a(r, n, econ.tax, "sl", 0.0, n), t_cash, n)]
    sched_it = econ.sched_it
    if econ.bonus_after is not None and t_cash > econ.bonus_after:
        sched_it = "bonus"
    a_it = a(r, econ.n_it, econ.tax, sched_it, econ.L_it, econ.n_tax_it)
    a_fac = a(r, econ.n_fac, econ.tax, econ.sched_fac, econ.L_fac, econ.n_tax_fac)
    return [
        (econ.s_it, a_it, t_cash + econ.L_it, econ.n_it),
        (1.0 - econ.s_it, a_fac, t_cash + econ.L_fac, econ.n_fac),
    ]


def vintage_requirement(v: Vintage, econ: Econ, r: float, u: float, w: float, midyear: bool = True) -> float:
    """Requirement of one vintage over [u, w): amount * sum_b s_b * a_b * overlap([u,w), service window)."""
    t_cash = _t_cash(v, midyear)
    total = 0.0
    for share, ab, s0, n in _buckets(v, econ, r, t_cash):
        total += share * ab * _overlap(u, w, s0, s0 + n)
    return v.amount * total


def requirement(vintages: Sequence[Vintage], econ: Econ, r: float, u: float, w: float,
                midyear: bool = True) -> float:
    total = 0.0
    for v in vintages:
        total += vintage_requirement(v, econ, r, u, w, midyear)
    return total


# --------------------------------------------------------------------------------------
# Contribution, H1
# --------------------------------------------------------------------------------------

def contribution(flow: Flow, include_rent: bool = True, margin_own_filed: bool = True) -> float:
    """revenue * m_pre - rent, less in-layer rent when the buyer's margin is not built from its own filed costs."""
    c = flow.revenue * flow.m_pre
    if include_rent:
        c -= flow.rent
    if not margin_own_filed:
        c -= flow.in_layer_rent
    return c


def revenue_totals(entities: Sequence[Entity], flows: Dict[str, Flow]) -> Dict[str, float]:
    """Total revenue gross and net of in-layer rent (in-layer rent is revenue another in-layer entity also books)."""
    gross = 0.0
    il = 0.0
    for e in entities:
        f = flows.get(e.name)
        if f is None:
            continue
        gross += f.revenue
        il += f.in_layer_rent
    return {"gross": gross, "net": gross - il, "in_layer_rent": il}


def cov1(entities: Sequence[Entity], flows: Dict[str, Flow], r: float, midyear: bool = True,
         include_rent: bool = True, extra_vintages: Optional[Dict[str, Sequence[Vintage]]] = None) -> Dict:
    """H1 stock coverage for one interval: sum C / sum Req over all live vintages (opening stock included).

    Each entity is evaluated over its own flow interval. cov1 is None (with reason) when sum Req <= 0.
    """
    C = 0.0
    R = 0.0
    per = {}
    for e in entities:
        f = flows.get(e.name)
        if f is None:
            continue
        vs = list(e.vintages)
        if extra_vintages and e.name in extra_vintages:
            vs = vs + list(extra_vintages[e.name])
        req = requirement(vs, e.econ, r, f.start, f.end, midyear)
        c = contribution(f, include_rent, e.margin_own_filed)
        per[e.name] = {"C": c, "req": req}
        C += c
        R += req
    out = {"C": C, "req": R, "per_entity": per, "cov1": None, "reason": None}
    if R > 0:
        out["cov1"] = C / R
    else:
        out["reason"] = "sum of requirement <= 0"
    return out


def cov1_lease_toggle(entities: Sequence[Entity], flows: Dict[str, Flow], r: float,
                      lease_vintages: Dict[str, Sequence[Vintage]], toggle: bool, include_rent: bool = True,
                      midyear: bool = True) -> Dict:
    """Memo variant. With toggle on, operating-lease ROU additions become vintages annuitised over the lease term
    at r (facilities-like: entity tax rate, "sl" over the term, no build lag) and rent leaves the contribution.

    Raises ValueError if rent is included and the toggle is on (that would count the lease twice).
    Lease vintages must carry lease_term (the disclosed term, years).
    """
    if toggle and include_rent:
        raise ValueError("lease toggle on with rent included would count operating leases twice")
    if not toggle:
        return cov1(entities, flows, r, midyear, include_rent)
    extra = {}
    for name, vs in lease_vintages.items():
        for v in vs:
            if v.lease_term is None or v.lease_term <= 0:
                raise ValueError("lease vintage needs lease_term > 0")
        extra[name] = list(vs)
    return cov1(entities, flows, r, midyear, include_rent, extra)


# --------------------------------------------------------------------------------------
# Trends and H2
# --------------------------------------------------------------------------------------

def ols_line(points: Sequence[Tuple[float, float]]) -> Callable[[float], float]:
    """Ordinary least squares y = ym + b (x - xm). Needs >= 2 distinct x."""
    n = len(points)
    if n < 2:
        raise ValueError("need at least two points for a trend")
    xm = 0.0
    ym = 0.0
    for x, y in points:
        xm += x
        ym += y
    xm /= n
    ym /= n
    sxx = 0.0
    sxy = 0.0
    for x, y in points:
        sxx += (x - xm) * (x - xm)
        sxy += (x - xm) * (y - ym)
    if sxx == 0:
        raise ValueError("trend points have no spread in time")
    b = sxy / sxx
    return lambda t: ym + b * (t - xm)


def growth_trend(points: Sequence[Tuple[float, float]], decay: float = 1.0) -> Callable[[float], float]:
    """CAGR between the first and last points, compounded from the last point.

    rho = ln(y_last / y_first) / (x_last - x_first)  (continuous rate = ln(1+CAGR)).
    decay == 1: level(t) = y_last * exp(rho * (t - x_last)).
    decay != 1: the rate decays by `decay` per year: rho(s) = rho * decay^s, so
                level(t) = y_last * exp(rho * (1 - decay^k) / (-ln decay)),  k = t - x_last.
    Points must have positive values.
    """
    pts = sorted(points)
    (x0, y0), (x1, y1) = pts[0], pts[-1]
    if x1 <= x0:
        raise ValueError("need a time spread for CAGR")
    if y0 <= 0 or y1 <= 0:
        raise ValueError("CAGR trend needs positive first and last values")
    rho = log(y1 / y0) / (x1 - x0)

    def f(t: float) -> float:
        k = t - x1
        if decay == 1.0:
            return y1 * exp(rho * k)
        return y1 * exp(rho * (1.0 - decay ** k) / (-log(decay)))
    return f


@dataclass
class Trend:
    capex: Callable[[float], float]   # annual capex trend at time t
    rev: Callable[[float], float]     # annual revenue trend at time t
    base_end: float                   # vintages starting at or after this are post-base


def _zero(_t: float) -> float:
    return 0.0


def fit_trend(entity: Entity, capex_points: Sequence[Tuple[float, float]], rev_points: Sequence[Tuple[float, float]],
              base_end: float, trend: str = "linear", decay: float = 1.0) -> Trend:
    """Fit an entity's counterfactual. *_points = [(fiscal-year midpoint, value)] over the base fiscal years."""
    if entity.no_base:
        return Trend(_zero, _zero, base_end)
    if trend == "linear":
        return Trend(ols_line(capex_points), ols_line(rev_points), base_end)
    if trend == "cagr":
        return Trend(growth_trend(capex_points, 1.0), growth_trend(rev_points, 1.0), base_end)
    if trend == "decay":
        return Trend(growth_trend(capex_points, decay), growth_trend(rev_points, decay), base_end)
    raise ValueError("unknown trend %r" % (trend,))


def delta_vintages(entity: Entity, trend: Trend) -> List[Vintage]:
    """Post-base vintages with the counterfactual removed: dK_v = K_v - K*_v (no clipping)."""
    out = []
    for v in entity.vintages:
        if v.opening or v.start < trend.base_end - EPS_TIME:
            continue
        scale = v.length if v.stub else 1.0
        kstar = trend.capex(v.t_mid) * scale
        out.append(replace(v, amount=v.amount - kstar))
    return out


def h2_interval(entities: Sequence[Entity], flows: Dict[str, Flow], r: float, trends: Dict[str, Trend],
                midyear: bool = True, eps: float = 1e-9) -> Dict:
    """H2 above-trend test for one interval. Cov2 = sum dC / sum dReq, None with reason when sum dReq <= eps."""
    sdC = 0.0
    sdReq = 0.0
    per = {}
    for e in entities:
        f = flows.get(e.name)
        if f is None:
            continue
        tr = trends[e.name]
        scale = f.end - f.start if f.stub else 1.0
        rev_star = tr.rev(f.t_mid) * scale
        dv = delta_vintages(e, tr)
        dK = 0.0
        for v in dv:
            dK += v.amount
        dReq = requirement(dv, e.econ, r, f.start, f.end, midyear)
        base_c = 0.0 if e.no_base else rev_star * e.m_pre_base - e.rent_base
        dRev = f.revenue - rev_star
        dC = contribution(f, True, e.margin_own_filed) - base_c
        per[e.name] = {"dRev": dRev, "dC": dC, "dK": dK, "dReq": dReq,
                       "incr_margin": (dC / dRev) if dRev != 0 else None}
        sdC += dC
        sdReq += dReq
    out = {"per_entity": per, "dC": sdC, "dReq": sdReq, "cov2": None, "reason": None}
    if sdReq > eps:
        out["cov2"] = sdC / sdReq
    else:
        out["reason"] = "sum of dReq <= 0: no above-trend capital to cover"
    return out


def h2_cumulative(entities: Sequence[Entity], flows_list: Sequence[Dict[str, Flow]], r: float,
                  trends: Dict[str, Trend], cf: Optional[Dict[str, float]] = None,
                  cf_m_pre: Optional[Dict[str, float]] = None, midyear: bool = True, eps: float = 1e-9) -> Dict:
    """Cumulative H2 over several intervals: sum_intervals sum_e dC / sum_intervals sum_e dReq.

    cf = circular funding (cumulative cash a cloud funded into labs that are its customers), per entity.
    Each is capped at that entity's cumulative positive dRev. Returns cov2_cum unadjusted, less CF * m_pre
    (m_pre = cf_m_pre[name], default the entity's m_pre in its last interval), and less CF in full.
    """
    intervals = []
    sdC = 0.0
    sdReq = 0.0
    per_cum = {}
    pos_rev = {}
    last_m = {}
    for flows in flows_list:
        res = h2_interval(entities, flows, r, trends, midyear, eps)
        intervals.append(res)
        sdC += res["dC"]
        sdReq += res["dReq"]
        for name, d in res["per_entity"].items():
            c = per_cum.setdefault(name, {"dRev": 0.0, "dC": 0.0, "dReq": 0.0, "dK": d["dK"]})
            c["dRev"] += d["dRev"]
            c["dC"] += d["dC"]
            c["dReq"] += d["dReq"]
            pos_rev[name] = pos_rev.get(name, 0.0) + (d["dRev"] if d["dRev"] > 0 else 0.0)
            last_m[name] = flows[name].m_pre
    for c in per_cum.values():
        c["incr_margin"] = (c["dC"] / c["dRev"]) if c["dRev"] != 0 else None

    cf_capped = {}
    cf_margin_total = 0.0
    cf_full_total = 0.0
    if cf:
        for name, amt in cf.items():
            cap = pos_rev.get(name, 0.0)
            capped = amt if amt < cap else cap
            if capped < 0:
                capped = 0.0
            cf_capped[name] = capped
            m = (cf_m_pre or {}).get(name, last_m.get(name, 0.0))
            cf_margin_total += capped * m
            cf_full_total += capped

    out = {"intervals": intervals, "per_entity": per_cum, "dC": sdC, "dReq": sdReq,
           "cf_capped": cf_capped, "cov2_cum": None, "cov2_less_cf_margin": None, "cov2_less_cf_full": None,
           "reason": None}
    if sdReq > eps:
        out["cov2_cum"] = sdC / sdReq
        out["cov2_less_cf_margin"] = (sdC - cf_margin_total) / sdReq
        out["cov2_less_cf_full"] = (sdC - cf_full_total) / sdReq
    else:
        out["reason"] = "sum of dReq <= 0: no above-trend capital to cover"
    return out


# --------------------------------------------------------------------------------------
# Forecast (H1 basis)
# --------------------------------------------------------------------------------------

@dataclass
class ForecastInput:
    entity: Entity                    # historical vintages (opening stock included) and economics
    rev_last: float                   # last historical fiscal year revenue
    m_pre: float
    rent_last: float                  # last historical fiscal year operating rent
    first_start: float                # start of the first forecast fiscal year
    capex: List[float]                # forecast capex per future fiscal year
    g: float = 0.0                    # revenue growth
    delta: float = 0.0                # price decline (separate multiplicative term)
    added_rent: List[float] = field(default_factory=list)  # additional committed rent per future year
    in_layer_rent: float = 0.0        # constant annual in-layer rent paid (applies if not margin_own_filed)
    year1_start: Optional[float] = None  # if set, forecast year 1's vintage (capex[0]) covers [year1_start, first_start + 1)
                                         # instead of the whole year (the H1 stub is in the history; capex[0] is the remainder)


def forecast_revenue(rev_last: float, g: float, delta: float, k: int) -> float:
    """Rev_y = Rev_last * (1+g)^k * (1-delta)^k."""
    return rev_last * (1.0 + g) ** k * (1.0 - delta) ** k


def forecast_h1(inputs: Sequence[ForecastInput], r: float, midyear: bool = True,
                labels: Optional[Sequence] = None) -> Dict:
    """Per forecast year k = 0..N (k = 0 is the last historical year): Cov1, revenue scale lambda
    (sum(lam*Rev*m - rent) = sum Req), revenue needed = lam * sum Rev, and the first year Cov1 >= 1.

    N = longest capex list. An entity with a shorter list adds no further vintages and holds its last added rent.
    `labels` (len N, for k = 1..N) names the years in the output.
    """
    N = 0
    for fi in inputs:
        if len(fi.capex) > N:
            N = len(fi.capex)
    years = []
    first_k = None
    for k in range(0, N + 1):
        C = 0.0
        R = 0.0
        revm = 0.0
        rent = 0.0
        rev = 0.0
        for fi in inputs:
            e = fi.entity
            u = fi.first_start + k - 1
            w = fi.first_start + k
            vs = list(e.vintages)
            for j in range(1, min(k, len(fi.capex)) + 1):
                v_start = fi.year1_start if (j == 1 and fi.year1_start is not None) else fi.first_start + j - 1
                vs.append(Vintage(fi.capex[j - 1], v_start, fi.first_start + j))
            req = requirement(vs, e.econ, r, u, w, midyear)
            rv = forecast_revenue(fi.rev_last, fi.g, fi.delta, k)
            if k == 0 or not fi.added_rent:
                add = 0.0
            else:
                add = fi.added_rent[min(k, len(fi.added_rent)) - 1]
            rt = fi.rent_last + add
            if not e.margin_own_filed:
                rt += fi.in_layer_rent
            C += rv * fi.m_pre - rt
            R += req
            revm += rv * fi.m_pre
            rent += rt
            rev += rv
        cov = (C / R) if R > 0 else None
        lam = ((R + rent) / revm) if revm > 0 else None
        need = (lam * rev) if lam is not None else None
        if k >= 1 and first_k is None and cov is not None and cov >= 1.0:
            first_k = k
        years.append({"k": k, "label": (labels[k - 1] if (labels is not None and k >= 1) else k),
                      "cov1": cov, "lam": lam, "revenue": rev, "revenue_needed": need,
                      "contribution": C, "req": R})
    return {"years": years, "first_k": first_k,
            "first_label": (None if first_k is None else years[first_k]["label"])}


def committed_rent_added(U: float, T: float, c0: float, c1: float, year_end: float) -> float:
    """Annual rent added by year-end `year_end` from leases not yet commenced.

    (U / T) * fraction of the commencement window [c0, c1] elapsed by year_end, capped at U / T.
    """
    if T <= 0:
        raise ValueError("lease term must be > 0")
    full = U / T
    if c1 <= c0:
        return full if year_end >= c1 else 0.0
    frac = (year_end - c0) / (c1 - c0)
    frac = min(1.0, max(0.0, frac))
    return full * frac


def committed_rent_schedule(U: float, T: float, c0: float, c1: float, year_ends: Sequence[float]) -> List[float]:
    return [committed_rent_added(U, T, c0, c1, y) for y in year_ends]


def committed_rent_midyear(U: float, T: float, c0: float, c1: float, year_start: float, year_end: float) -> float:
    """Mid-year convention (spec 7, L2): the rent charged in a year is the run-rate at the year's midpoint."""
    return committed_rent_added(U, T, c0, c1, (year_start + year_end) / 2.0)


def committed_rent_schedule_midyear(U: float, T: float, c0: float, c1: float, year_ends: Sequence[float],
                                    length: float = 1.0) -> List[float]:
    return [committed_rent_added(U, T, c0, c1, y - length / 2.0) for y in year_ends]


# --------------------------------------------------------------------------------------
# Breakeven and scenarios
# --------------------------------------------------------------------------------------

def breakeven(cov_fn: Callable[[float], Optional[float]], lo: float = 0.0, hi: float = 1.0,
              iters: int = 80) -> Optional[float]:
    """Bisection for cov_fn(r) == 1 on [lo, hi]. None if there is no sign change, or cov_fn returns None."""
    flo = cov_fn(lo)
    fhi = cov_fn(hi)
    if flo is None or fhi is None:
        return None
    flo -= 1.0
    fhi -= 1.0
    if flo == 0.0:
        return lo
    if fhi == 0.0:
        return hi
    if (flo > 0) == (fhi > 0):
        return None
    lo_pos = flo > 0
    for _ in range(iters):
        mid = (lo + hi) / 2.0
        fm = cov_fn(mid)
        if fm is None:
            return None
        if ((fm - 1.0) > 0) == lo_pos:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


def breakeven_h1(entities, flows, midyear: bool = True, include_rent: bool = True, extra_vintages=None,
                 iters: int = 80) -> Optional[float]:
    return breakeven(lambda r: cov1(entities, flows, r, midyear, include_rent, extra_vintages)["cov1"],
                     0.0, 1.0, iters)


def breakeven_h2_cum(entities, flows_list, trends, midyear: bool = True, iters: int = 80,
                     eps: float = 1e-9) -> Optional[float]:
    return breakeven(lambda r: h2_cumulative(entities, flows_list, r, trends, None, None, midyear, eps)["cov2_cum"],
                     0.0, 1.0, iters)


def scenario_sets(base: Dict, ranges: Dict[str, Dict[str, float]], favourable_end: Dict[str, str]) -> Dict[str, Dict]:
    """Three full parameter sets from range inputs.

    ranges[name] = {"low":..., "mid":..., "high":...}; favourable_end[name] in {"low","high"} says which end
    raises coverage for that input. Returns {"favourable","central","adverse"}: base overlaid with, per input,
    the favourable end / mid / the other end.
    """
    out = {"favourable": dict(base), "central": dict(base), "adverse": dict(base)}
    for name, rg in ranges.items():
        if name not in favourable_end:
            raise ValueError("no favourable end given for %r" % (name,))
        fav = favourable_end[name]
        if fav not in ("low", "high"):
            raise ValueError("favourable_end must be 'low' or 'high'")
        adv = "high" if fav == "low" else "low"
        out["favourable"][name] = rg[fav]
        out["central"][name] = rg["mid"]
        out["adverse"][name] = rg[adv]
    return out
