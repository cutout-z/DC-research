"""The page table component (block 07): one definition per table, one HTMX endpoint for all.

The variant follows the data, per the pass-1 rule (docs/table-audit.md): over 15 rows gets the
toolbar (search + sort), anything smaller renders compact. A table overrides that only with a
recorded reason. Grouping (block 07 C) is configuration, not a separate table.

Register a table once; the page template calls `m.datatable(view(...))` and every sort/search
request comes back through `/partials/t/{id}`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

TOOLBAR_THRESHOLD = 15


@dataclass(frozen=True)
class Col:
    key: str
    label: str
    kind: str = "text"      # text | num | mono | long (wraps) | bool (✓/—) | link (opens the URL) | grade (A/B/C pill) | status (freshness pill)
    width: str = ""         # a Tailwind width class for the <col>, e.g. "w-[18%]"
    fmt: str | Callable = "{:,.1f}"  # for kind == "num": a format string, or a function of the value
    help: str | None = None  # header help tip (authored copy)


@dataclass(frozen=True)
class TableDef:
    id: str
    title: str
    cols: tuple[Col, ...]
    rows: Callable[[], list[dict]]
    subtitle: str = ""
    source: str = ""
    group_by: str | None = None
    variant: str | None = None          # None = decided by the row count
    override_reason: str | None = None  # required when variant is set
    noun: tuple[str, str] = ("row", "rows")
    page_size: int = 25
    fill_page: bool = False   # the table IS the page: no inner scroll box; header sticks under the app bar
    min_width: str = "min-w-[640px]"  # wide tables (many numeric columns) scroll sideways below this
    wrap_headers: bool = False        # many narrow numeric columns: let headers take two lines
    natural: bool = False             # wide registers: columns size to content, short text stays on one line
    default_cols: tuple[str, ...] | None = None  # visible by default; the rest via the Columns menu
    params: tuple[str, ...] = ()      # page filter params passed through to rows(**params)
    include: str | None = None        # CSS selector of the page's filter form, sent with every request
    stack_labels: bool = False        # phones: a stacked row names each value (rows of several short values)
    # A column whose cell also carries the row's `_mark` ({"text", "href", "title"}), a small linked pill
    # after the value (Project Analysis: news since the row was last checked, app/review_flags.py).
    mark: str | None = None
    # Phones (< 640px). A table stacks each row into a block when it has a long-text column, or when
    # `stack` is True. Otherwise it may scroll sideways only with a recorded reason (`phone_scroll`):
    # scripts/verify_pages.py fails any table that neither stacks nor fits, unless it carries one.
    stack: bool | None = None
    phone_scroll: str | None = None

    def __post_init__(self):
        if self.variant and not self.override_reason:
            raise ValueError(f"table {self.id!r} overrides the variant without a recorded reason")
        if self.stack and self.phone_scroll:
            raise ValueError(f"table {self.id!r} both stacks and scrolls on phones")

    @property
    def stacks(self) -> bool:
        return self.stack if self.stack is not None else any(c.kind == "long" for c in self.cols)


REGISTRY: dict[str, TableDef] = {}


def register(t: TableDef) -> TableDef:
    REGISTRY[t.id] = t
    return t


def choose_variant(n_rows: int, override: str | None = None) -> str:
    return override or ("toolbar" if n_rows > TOOLBAR_THRESHOLD else "compact")


def view(table_id: str, q: str = "", sort: str | None = None, direction: str = "asc",
         page: int = 1, cols: list[str] | None = None, params: dict | None = None) -> dict:
    t = REGISTRY[table_id]
    all_rows = t.rows(**{k: v for k, v in (params or {}).items() if k in t.params})
    # A filter-driven table keeps the variant its full size earns: the search box must not
    # vanish because the page's filters narrowed it to a handful of rows.
    base_n = len(t.rows()) if t.params else len(all_rows)
    variant = choose_variant(base_n, t.variant)
    keys = [c.key for c in t.cols]

    rows = all_rows
    q = q.strip() if variant == "toolbar" else ""
    if q:
        needle = q.lower()
        rows = [r for r in rows if any(needle in str(r.get(k, "")).lower() for k in keys)]

    sort = sort if sort in keys else None   # None keeps the authored order
    if sort:
        rows = sorted(rows, key=lambda r: (r.get(sort) is None, str(r.get(sort)).lower()
                                           if not isinstance(r.get(sort), (int, float)) else r.get(sort)),
                      reverse=direction == "desc")

    groups = None
    if t.group_by:
        groups, index = [], {}
        for r in rows:  # groups keep their first-appearance (authored) order
            g = r.get(t.group_by)
            if g not in index:
                index[g] = len(groups)
                groups.append({"label": g, "rows": []})
            groups[index[g]]["rows"].append(r)

    total, matched = len(all_rows), len(rows)
    pages, start = 1, 0
    if variant == "toolbar" and not t.group_by and matched > t.page_size:
        pages = -(-matched // t.page_size)
        page = min(max(1, page), pages)
        start = (page - 1) * t.page_size
        rows = rows[start:start + t.page_size]
    else:
        page = 1

    return {"t": t, "variant": variant, "rows": rows, "groups": groups, "total": total,
            "matched": matched, "q": q, "sort": sort, "direction": direction,
            "page": page, "pages": pages, "start": start,
            "cols": _visible(t, cols), "all_cols": [c for c in t.cols if c.key != t.group_by],
            "chooser": bool(t.default_cols)}


def _visible(t: TableDef, cols: list[str] | None) -> list[Col]:
    """Columns shown: an explicit choice, else the table's defaults, else all. The first column
    (the row's identity) is always shown."""
    keys = [c.key for c in t.cols if c.key != t.group_by]
    want = [k for k in (cols or t.default_cols or keys) if k in keys]
    if keys and keys[0] not in want:
        want.insert(0, keys[0])
    return [c for c in t.cols if c.key in want and c.key != t.group_by]
