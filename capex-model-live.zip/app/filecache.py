"""Cache a loader (positional args allowed) against the files it reads.

The data root is updated by `git pull` under a running app, so a loader cached for the life of the
process (a bare `@lru_cache`) keeps serving the first data it read. `reload_on_change` keys the cache
on each source file's (mtime_ns, size); a rewritten file is re-read on the next call, an untouched one
costs a `stat`. A missing file keys as None, so it appearing later is noticed too.

Paths are given as a callable so they are looked up at call time (a test or the static export can
re-point the module's constants).
"""
from __future__ import annotations

import functools
from collections.abc import Callable, Iterable
from pathlib import Path


def _stamp(p: Path):
    try:
        s = Path(p).stat()
    except OSError:
        return None
    return (s.st_mtime_ns, s.st_size)


def reload_on_change(paths: Callable[[], Iterable[Path]]):
    def deco(fn):
        cache: dict = {}

        @functools.wraps(fn)
        def wrapper(*args):
            key = (tuple(_stamp(p) for p in paths()), args)
            try:
                return cache[key]
            except KeyError:
                pass
            # Load before touching the cache, and return the local value: a
            # concurrent request with another key may clear the dict between
            # our write and a re-read (sync endpoints run in a thread pool).
            value = fn(*args)
            # Drop entries for older file stamps; keep other args of the current one.
            for k in [k for k in cache if k[0] != key[0]]:
                cache.pop(k, None)
            cache[key] = value
            return value

        wrapper.cache_clear = cache.clear
        return wrapper
    return deco
