"""Authored markdown -> HTML for page copy (methodology notes, source callouts).

Only for copy that lives in app/content/ (ours, reviewed), never for data values. External links
open in a new tab without handing over the opener.
"""
from __future__ import annotations

import html as _html
import re

import markdown as _md
from markupsafe import Markup


def md(text: str, inline: bool = False) -> Markup:
    html = _md.markdown(text.strip(), extensions=["tables", "sane_lists"])
    html = re.sub(r'<a href="(https?://[^"]+)"', r'<a href="\1" target="_blank" rel="noopener noreferrer"', html)
    if inline:  # one paragraph, no wrapping <p>
        html = re.sub(r"^<p>(.*)</p>$", r"\1", html, flags=re.S)
    return Markup(html)


def md_untrusted(text: str) -> Markup:
    """Markdown written by someone else (a clipped note): any HTML in it is shown as text, links and
    images keep only http(s) targets, and an image becomes a link to it (the app embeds nothing remote)."""
    html = _md.markdown(_html.escape(text.strip(), quote=False), extensions=["sane_lists"])
    html = re.sub(r'<img [^>]*?src="([^"]*)"[^>]*?alt="([^"]*)"[^>]*>|<img [^>]*?alt="([^"]*)"[^>]*?src="([^"]*)"[^>]*>',
                  lambda m: f'<a href="{m[1] or m[4]}">{m[2] or m[3] or "image"}</a>', html)
    html = re.sub(r'<a href="(?!https?://)[^"]*"', '<a', html)
    html = re.sub(r'<a href="(https?://[^"]+)"', r'<a href="\1" target="_blank" rel="noopener noreferrer nofollow"', html)
    return Markup(html)
